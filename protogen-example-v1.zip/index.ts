import './styles.css';

import { Step, Workspace, Generator } from './models';

import { ActionsGenerator } from './generators/actions.generator';
import { AppComponentGenerator } from './generators/component-app.generator';
import { HomeComponentGenerator } from './generators/component-home.generator';
import { ComponentsGenerator } from './generators/components.generator';
import { CoreStateGenerator } from './generators/core-state.generator';
import { CoreStateModuleGenerator } from './generators/core-state-module.generator';
import { EffectsGenerator } from './generators/effects.generator';
import { FacadeGenerator } from './generators/facade.generator';
import { ProjectGenerator } from './generators/project.generator';
import { ReducerGenerator } from './generators/reducer.generator';
import { RoutesGenerator } from './generators/routes.generator';
import { SelectorsGenerator } from './generators/selectors.generator';
import { ServiceGenerator } from './generators/service.generator';

import { generate, prettyPrint, render } from './utils';
import { initClipboard } from './clipboard';

// -------------------------------------------------------------------
// THE MODEL
// -------------------------------------------------------------------
export enum Libs {
  DATA_MODULE     = 'core-data',
  STATE_MODULE    = 'core-state',
  MATERIAL_MODULE = 'material',
  LOGIN_MODULE    = 'ui-login',
  TOOLBAR_MODULE  = 'ui-toolbar',
}

const workspace: Workspace = {
  name: 'bba-breezy-gen',
  application: 'dashboard',
  scope: 'bba',
  dependencies: [
    '@angular/material',
    '@ngrx/store@latest',
  ],
  entities: [
    { plural: 'steps', singular: 'step'},
    { plural: 'generators', singular: 'generator'},
    { plural: 'templates', singular: 'template'},
  ],
  libs: Object.values(Libs),
  options: {
    libs: '--style=scss && \\',
    components: '-m app.module.ts --style=scss && \\',
    routing: '--flat=true -m=app.module.ts && \\',
  },
  endpoints: {
    api: 'http://localhost:3000/'
  }
}

const config = {
  data: Object.assign({}, workspace, { module: Libs.DATA_MODULE }),
  state: Object.assign({}, workspace, { module: Libs.STATE_MODULE }),
  login: { component: 'login', project: 'ui-login', options: workspace.options.libs},
  toolbar: { component: 'toolbar', project: 'ui-toolbar', options: workspace.options.libs},
  notification: { entity: {single: 'notification', plural: 'notifications'}, module: Libs.DATA_MODULE},
  home: { entity: { plural: 'home' }, options: workspace.options.components},
  workspace: { entity: { plural: 'workspace' }, options: workspace.options.components},
  config: { entity: { plural: 'config' }, options: workspace.options.components},
  output: { entity: { plural: 'output' }, options: workspace.options.components},
  routing: { options: workspace.options.routing},
}

// -------------------------------------------------------------------
// THE STEPS
// -------------------------------------------------------------------
const mainSteps: Step[] = [
  { target: 'Workspace', args: workspace },
  { target: 'Dependencies', args: workspace },
  { target: 'Libs', args: workspace },
  { target: 'Data Layer', args: config.data },
  { target: 'State Layer', args: config.state },
  { target: 'Component Layer', args: workspace },
  { target: 'Routing', args: config.routing },
];

const extraSteps: Step[] = [
  { target: 'Lib Component', args: config.login },
  { target: 'Lib Component', args: config.toolbar },
  { target: 'Service', args: config.notification },
  { target: 'Container Component', args: config.home },
  { target: 'Container Component', args: config.workspace },
  { target: 'Container Component', args: config.config },
  { target: 'Container Component', args: config.output },
];

const steps: Step[] = [...mainSteps, ...extraSteps];

// -------------------------------------------------------------------
// CODE NAME: Tiny Diamond 💎
// -------------------------------------------------------------------

// -------------------------------------------------------------------
// RELEASE THE KRAKEN!🐙
// -------------------------------------------------------------------
const logging         = false;

const project         = new ProjectGenerator(workspace, steps, logging);
const state           = CoreStateGenerator.generate(workspace.entities, workspace.scope);
const stateModule     = CoreStateModuleGenerator.generate(workspace.entities, workspace.scope);
const routes          = RoutesGenerator.generate(workspace.entities, workspace.scope);
const root            = AppComponentGenerator.generate(workspace.entities, workspace.scope);
const home            = HomeComponentGenerator.generate(workspace.entities, workspace.scope);

// render('project',     [project.output], 'none', logging);
// render('state',       [state, stateModule], 'typescript', logging);
render('routes',      [routes], 'typescript', logging);
render('root',        [root], 'typescript', logging);
// render('home',        [home], 'typescript', logging);
// render('services',    generate(workspace, ServiceGenerator), 'typescript', logging);
// render('facades',     generate(workspace, FacadeGenerator), 'typescript', logging);
// render('reducers',    generate(workspace, ReducerGenerator), 'typescript', logging);
// render('actions',     generate(workspace, ActionsGenerator), 'typescript', logging);
// render('selectors',   generate(workspace, SelectorsGenerator), 'typescript', logging);
// render('effects',     generate(workspace, EffectsGenerator), 'typescript', logging);
// render('components',  generate(workspace, ComponentsGenerator), 'typescript', logging);

// COPY THE KRAKEN! 🐙
const clipboard       = initClipboard('.btn');