import { Libs } from './';

export interface Entity {
  singular: string;
  plural: string;
}

export interface Workspace {
  name: string;
  application: string;
  scope: string;
  dependencies: string[];
  entities: Entity[];
  libs: Libs;
  options: Record<string, any>;
  endpoints: Record<string, any>;
}

export interface Step {
  target: string;
  args: Record<string, any>;
}

export interface Generator {
  generate(entity: Entity, scope: string): string;
}