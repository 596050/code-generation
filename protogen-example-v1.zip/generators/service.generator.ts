import { capitalize } from '../utils';

const generate = (entity, scope) => {
  const obj         = `${entity.singular}`;
  const objs        = `${entity.plural}`;
  const model       = capitalize(obj);
  const models      = capitalize(objs);
  const modelParam  = `${obj}: ${model}`;
  const modelsParam = `${objs}: ${model}[]`;

  const template = `
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ${model} } from '@${scope}/api-interfaces';
import { environment } from '@${scope}/environments';

@Injectable({
  providedIn: 'root'
})
export class ${models}Service {
  model = '${objs}';

  constructor(private http: HttpClient) { }

  all() {
    return this.http.get<${model}[]>(this.getUrl());
  }

  find(id: string) {
    return this.http.get<${model}>(this.getUrlWithId(id));
  }

  create(${modelParam}) {
    return this.http.post(this.getUrl(), ${obj});
  }

  update(${modelParam}) {
    return this.http.put(this.getUrlWithId(${obj}.id), ${obj});
  }

  delete(id: number) {
    return this.http.delete(this.getUrlWithId(id));
  }

  private getUrl() {
    return \`\${environment.apiEndpoint}\${this.model}\`;
  }

  private getUrlWithId(id) {
    return \`\${this.getUrl()}/\${id}\`;
  }
}
  `;

  return template;
}

export const ServiceGenerator = {
  generate
}