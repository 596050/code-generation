import { capitalize } from '../utils';
const generateContainerComponent = (entity, scope) => {
  const obj         = `${entity.singular}`;
  const objs        = `${entity.plural}`;
  const model       = capitalize(obj);
  const models      = capitalize(objs);
  const modelParam  = `${obj}: ${model}`;

  const template = `
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ${model} } from '@${scope}/api-interfaces';
import { ${models}Facade } from '@${scope}/core-state';

@Component({
  selector: '${scope}-${objs}',
  templateUrl: './${objs}.component.html',
  styleUrls: ['./${objs}.component.scss']
})
export class ${models}Component implements OnInit {
  ${objs}\$: Observable&lt;${model}[]> = this.${objs}Facade.all${models}\$;
  selected${model}\$: Observable&lt;${model}> = this.${objs}Facade.selected${model}\$;

  constructor(
    private ${objs}Facade: ${models}Facade
  ) { }

  ngOnInit(): void {
    this.reset();
    this.${objs}Facade.mutations\$.subscribe(_ => this.reset());
  }

  reset() {
    this.loadCourses();
    this.${objs}Facade.select${model}(null);
  }

  select${model}(${modelParam}) {
    this.${objs}Facade.select${model}(${obj}.id);
  }

  load${models}() {
    this.${objs}Facade.load${models}();
  }

  save${model}(${modelParam}) {
    if (${obj}.id) {
      this.${objs}Facade.update${model}(${obj});
    } else {
      this.${objs}Facade.create${model}(${obj});
    }
  }

  delete${model}(${modelParam}) {
    this.${objs}Facade.delete${model}(${obj});
  }
}
`;
  return template;
}

const generateListComponent = (entity, scope) => {
  const obj         = `${entity.singular}`;
  const objs        = `${entity.plural}`;
  const model       = capitalize(obj);
  const models      = capitalize(objs);

  const template = `
import { Component, Input, Output, EventEmitter } from '@angular/core';

import { ${model} } from '@${scope}/api-interfaces';

@Component({
  selector: '${scope}-${objs}-list',
  templateUrl: './${objs}-list.component.html',
  styleUrls: ['./${objs}-list.component.scss']
})
export class ${models}ListComponent {
  @Input() ${objs}: ${model}[];
  @Input() readonly = false;
  @Output() selected = new EventEmitter();
  @Output() deleted = new EventEmitter();
}
`;
  return template;
}

const generateDetailsComponent = (entity, scope) => {
  const obj         = `${entity.singular}`;
  const model       = capitalize(obj);

  const template = `
import { Component, EventEmitter, Input, Output } from '@angular/core';

import { ${model} } from '@${scope}/api-interfaces';

@Component({
  selector: '${scope}-${obj}-details',
  templateUrl: './${obj}-details.component.html',
  styleUrls: ['./${obj}-details.component.scss']
})
export class ${model}DetailsComponent {
  selected${model}: ${model};
  originalTitle = '';
  @Input() set ${obj}(value: ${model}) {
    if(value) this.originalTitle = value.title;
    this.selected${model} = {...value};
  };
  @Output() saved = new EventEmitter;
  @Output() cancelled = new EventEmitter;
}
`;
  return template;
}

const generateContainerTemplate = (entity, scope) => {
  const obj     = `${entity.singular}`;
  const objs    = `${entity.plural}`;
  const model   = capitalize(obj);
  const single  = `${scope}-${obj}`;
  const plural  = `${scope}-${objs}`;

  const template = `
<div class="${objs}-containers">
  <div class="${objs}-list">
    <${plural}-list [${objs}]="${objs}\$ | async"
      (selected)="select${model}(\$event)"
      (deleted)="delete${model}(\$event)">
    </${plural}-list>
  </div>
  <div class="${obj}-details">
    <${single}-details [${obj}]="selected${model}"
      (saved)="save${model}(\$event)"
      (cancelled)="reset${model}()">
    </${single}-details>
  </div>
</div>
`;

  return template;
}

const generateListTemplate = (entity, scope) => {
  const obj     = `${entity.singular}`;
  const objs    = `${entity.plural}`;

  const template = `
<mat-card>
  <mat-card-content>
    <mat-list>
      <mat-list-item *ngFor="let ${obj} of ${objs}" class="mat-list-option" (click)="selected.emit(${obj})">
        <span matLine>{{${obj}.title}}</span>
        <button *ngIf="!readonly" mat-icon-button type="button" color="warn" (click)="deleted.emit(${obj}); $event.stopImmediatePropagation()">
          <mat-icon>clear</mat-icon>
        </button>
      </mat-list-item>
    </mat-list>
  </mat-card-content>
</mat-card>
`;

  return template;
}

const generateDetailsTemplate = (entity, scope) => {
  const obj         = `${entity.singular}`;
  const objs        = `${entity.plural}`;
  const model       = capitalize(obj);

  const template = `
<mat-card>
  <mat-card-title>
    <span *ngIf="current${model}.id; else elseBlock">
      {{ originalTitle | titlecase }}
    </span>
    <ng-template #elseBlock>
      Select ${model}
    </ng-template>
  </mat-card-title>
  <form #form="ngForm" (submit)="saved.emit(current${model})">
    <mat-card-content>
      <mat-form-field class="full-width">
        <input
          matInput
          placeholder="Title"
          [(ngModel)]="current${model}.title"
          type="text"
          name="title"
          required />
      </mat-form-field>
    </mat-card-content>
    <mat-card-actions>
      <button [disabled]="form.invalid" type="submit" mat-button color="primary">Save</button>
      <button type="button" mat-button (click)="form.reset();cancelled.emit()">
        Cancel
      </button>
    </mat-card-actions>
  </form>
</mat-card>
`;

  return template;
}

const generate = (entity, scope) => {
  return `
// The Container Component
${generateContainerComponent(entity, scope)}
// The List Component
${generateListComponent(entity, scope)}
// The Details Component
${generateDetailsComponent(entity, scope)}
<script type="text/plain" class="language-markup">
// The Container Template
${generateContainerTemplate(entity, scope)}
// The List Template
${generateListTemplate(entity, scope)}
// The Details Template
${generateDetailsTemplate(entity, scope)}
</script>
  `;
}

export const ComponentsGenerator = {
  generate
}