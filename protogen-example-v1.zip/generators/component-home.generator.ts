import { capitalize } from '../utils';


const generateComponentRefs = (entities, scope) => {
  let output = '';
  entities.forEach(entity => {
    const objs    = `${entity.plural}`;
    const selector  = `${scope}-${objs}-list`;
    output += `<${selector} [${objs}]="${objs}\$ | async" [readonly]="true"></${selector}>\n`;
  });
  return output;  
}

const generateImports = (entities) => {
  let output = '';
  entities.forEach(entity => output += `${capitalize(entity.plural)}Facade,\n`);
  return output;
}

const generateSelectors = (entities) => {
  let output = '';
  entities.forEach(entity => {
    output += `${entity.plural}\$: Observable&lt;${capitalize(entity.singular)}[]> = this.${entity.plural}Facade.all${capitalize(entity.plural)}\$;\n`;
  });
  return output;
}

const generateDI = (entities) => {
  let output = '';
  entities.forEach(entity => {
    output += `private ${entity.plural}Facade: ${capitalize(entity.plural)}Facade,\n`;
  });
  return output;
}

const generateCommands = (entities) => {
  let output = '';
  entities.forEach(entity => {
    output += ` this.${entity.plural}Facade.load${capitalize(entity.plural)}();\n`;
  });
  return output;
}

const generateComponent = (entities, scope) => {
  const template = `
import { Component, OnInit } from '@angular/core';
import { Course, Lesson, User } from '@${scope}/api-interfaces';
import { 
${generateImports(entities)}
} from '@${scope}/core-state';
import { Observable } from 'rxjs';

@Component({
  selector: '${scope}-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
${generateSelectors(entities)}
  constructor(
${generateDI(entities)}
  ) { }

  ngOnInit(): void {
${generateCommands(entities)}
  }
}
`;
  return template;
}

const generateTemplate = (entities, scope)  => {
  const template = `
<div class="home-container">
${generateComponentRefs(entities, scope)}
</div>
`;
  return template;
}

const generate = (entities, scope) => {
  return `
${generateComponent(entities, scope) }
<script type="text/plain" class="language-markup">
${generateTemplate(entities, scope) }
</script>
  `;
}

export const HomeComponentGenerator = {
  generate
}