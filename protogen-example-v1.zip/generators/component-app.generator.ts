import { capitalize } from '../utils';

const generateLinks = (entities) => {
  let output = '';
  // Generate default routes
  output += `{ path: '/home', icon: 'home', title: 'Home' },\n`
  // Generate the rest of the routes
  entities.forEach(entity => output += `{ path: '/${entity.plural}', icon: 'view_list', title: '${capitalize(entity.plural)}' },\n`);
  return output;
}

const generateComponent = (entities, scope) => {
  const template = `
import { Component } from '@angular/core';
import { Observable, of } from 'rxjs';

export enum SidenavStatus {
  OPENED = 'opened',
  DISABLED = 'disabled',
  CLOSED = 'closed',
}

@Component({
  selector: '${scope}-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'Application';
  links = [
${generateLinks(entities)}
  ];

  isAuthenticated\$: Observable&lt;boolean> = of(true);
  sidenavStatus = SidenavStatus.OPENED;

  constructor() {}

  logout() {}

  toggleSidenav() {
    this.sidenavStatus =
      this.sidenavStatus === SidenavStatus.OPENED
        ? SidenavStatus.CLOSED
        : SidenavStatus.OPENED;
  }
}
`;
  return template;
}

const generateTemplate = () => {
  const template = `
<bba-toolbar
  [title]="title"
  [isAuthenticated]="isAuthenticated\$ | async"
  [sidenavEnabled]="sidenavStatus !== 'disabled'"
  (logout)="logout()"
  (toggleSidenav)="toggleSidenav()">
</bba-toolbar>

<mat-sidenav-container>
  <mat-sidenav #sidenav
    *ngIf="(isAuthenticated\$ | async) as authenticated"
    [opened]="sidenavStatus === 'opened'" mode="side" class="app-sidenav">
    <ng-container>
      <span class="logo">
        <a [routerLink]="'/'">
          <img src="assets/images/logo.svg" alt="Logo">
        </a>
      </span>
      <nav>
        <div>
          <div *ngFor="let link of links">
            <a mat-button class="nav-link" [routerLink]="link.path" routerLinkActive="active">
              <mat-icon>
                {{link.icon}}
              </mat-icon>
              <span>
                {{link.title}}
              </span>
            </a>
          </div>
        </div>
      </nav>
    </ng-container>
  </mat-sidenav>

  <div class="container">
    <router-outlet></router-outlet>
  </div>
</mat-sidenav-container>
`;

  return template;
}

const generate = (entity, scope) => {
  return `
${generateComponent(entity, scope)}
<script type="text/plain" class="language-markup">
${generateTemplate()}
</script>
  `;
}

export const AppComponentGenerator = {
  generate
}