import { capitalize } from '../utils';

const generateImports = (entities) => {
  let output = '';
  entities.forEach(entity =>
    output += `import { ${capitalize(entity.plural)}Component } from './${entity.plural}/${entity.plural}.component';\n`);
  return output;
}

const generateRoutes = (entities) => {
  let output = '';
  // Generate default routes
  output += `{ path: '', component: HomeComponent },\n`
  output += `{ path: 'login', component: LoginComponent },\n`
  // Generate the rest of the routes
  entities.forEach(entity => output += `{ path: '${entity.plural}', component: ${capitalize(entity.plural)}Component },\n`);
  return output;
}

const generate = (entities, scope) => {
  const template = `
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from '@bba/ui-login';
import { HomeComponent } from './home/home.component';
${generateImports(entities)}
const routes: Routes = [
${generateRoutes(entities)}
  { path: '**', redirectTo: '/' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class RoutingModule {}
  `;

  return template;
}

export const RoutesGenerator = {
  generate
}
