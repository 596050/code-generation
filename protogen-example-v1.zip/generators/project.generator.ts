import { Entity, Step } from './models';

export class ProjectGenerator {
  output = '';
  
  constructor(private workpace, private steps, private logging) {
    this.generateSteps({steps, logging});
    this.output = this.trimEnd(this.output, '&& \\');
  }
  
  // -------------------------------------------------------------------
  // THE STEPS
  // -------------------------------------------------------------------
  generateSteps = ({steps, logging}: { steps: Step[], logging: boolean}) => {
    steps.forEach((step, index) => {
      this.logMessage(`# Step ${index+1}: Generating ${step.target}`, logging);
      this[`generate${this.removeSpaces(step.target)}`](step.args);
    })
  };


  // -------------------------------------------------------------------
  // WORKSPACE
  // -------------------------------------------------------------------
  generateWorkspace = ({name, application, scope}) => {
    return this.echo(`\n npx create-nx-workspace@latest ${name} \\
      --appName=${application} \\
      --preset=angular-nest \\
      --npmScope=${scope} \\
      --style=scss && \\\n cd ${name}/ && \\`);
  }

  generateDependencies = ({dependencies}) => dependencies.forEach(this.addDependency);

  addDependency = dependency => this.echo(`\n nx add ${dependency}  && \\`);

  // -------------------------------------------------------------------
  // LIBS
  // -------------------------------------------------------------------
  generateLibs = ({libs, options}) => libs.forEach(lib => this.generateCoreLib(lib, options.libs));

  generateCoreLib = (lib, option) => this.echo(`\n nx g lib ${lib} ${option}`);

  // -------------------------------------------------------------------
  // SERVICE LAYER
  // -------------------------------------------------------------------
  generateDataLayer = ({entities, module}: { entities: Entity[], module: string}) => {
    entities.forEach(entity => this.generateService({entity, module}));
  };

  generateStateLayer = ({entities, module}: { entities: Entity[], module: string}) => {
    entities.forEach(entity => this.generateNgRx({entity, module}));
  };

  generateService = ({entity, module}: { entity: Entity, module: string}) => {
    this.echo(`\n nx g s services/${entity.plural}/${entity.plural} --project=${module} && \\`);
  }

  generateNgRx = ({ entity, module }: { entity: Entity, module: string}) => {
    this.echo(`\n nx g @nrwl/angular:ngrx ${entity.plural} \\
      --module=libs/${module}/src/lib/${module}.module.ts \\
      --directory ${entity.plural} \\
      --defaults \\
      --facade && \\`);
  };

  // -------------------------------------------------------------------
  // COMPONENT LAYER
  // -------------------------------------------------------------------
  generateComponentLayer = ({entities, options}: { entities: Entity[], options: Record<string, any>}) => {
    entities.forEach(entity => {
      const args = {entity,  options: options.components};
      this.generateContainerComponent(args);
      this.generateListComponent(args);
      this.generateDetailsComponent(args);
    })
  };

  generateContainerComponent = ({entity, options}: { entity: Entity, options: string}) => {
    this.echo(`\n nx g c ${entity.plural} ${options}`);
  };

  generateListComponent = ({entity, options}: { entity: Entity, options: string}) => {
    this.echo(`\n nx g c ${entity.plural}/${entity.plural}-list ${options}`);
  };

  generateDetailsComponent = ({entity, options}: { entity: Entity, options: string}) => {
    this.echo(`\n nx g c ${entity.plural}/${entity.singular}-details ${options}`);
  };

  generateLibComponent = ({component, project, options}) => {
    this.echo(`\n nx g c ${component} --project ${project} ${options}`);
  };

  generateRouting = ({options}) => this.echo(`\n nx g m routing ${options}`);

  // -------------------------------------------------------------------
  // UTILITIES
  // -------------------------------------------------------------------
  echo = message => this.output += message;

  logMessage = (message, logging) => {
    this.echo(logging ? `\n\n <strong>${message}</strong> \n` : '')
  };

  removeSpaces = val => val.replace(/ /g, '');

  trimEnd = (str, sub) => {
    return str.slice(0, str.lastIndexOf(sub));
  }
}