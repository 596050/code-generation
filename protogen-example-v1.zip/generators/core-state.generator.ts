import { capitalize } from '../utils';

const generateImports = (entities) => {
  let output = '';
  entities.forEach(entity => 
    output += `import * as from${capitalize(entity.plural)} from './${entity.plural}/${entity.plural}.reducer';\n`)
  return output;
}

const generateState = (entities) => {
  let output = '';
  entities.forEach(entity => {
    const models = capitalize(entity.plural);
    output += `[from${models}.${models.toUpperCase()}_FEATURE_KEY]: from${models}.${models}State;\n`;
  });
  return output;
}

const generateReducer = (entities) => {
  let output = '';
  entities.forEach(entity => {
    const models = capitalize(entity.plural);
    output += `[from${models}.${models.toUpperCase()}_FEATURE_KEY]: from${models}.${entity.plural}Reducer,\n`;
  });
  return output;
}

const generate = (entities, scope) => {
  const template = `
import { Params } from '@angular/router';
import * as fromRouter from '@ngrx/router-store';
import { ActionReducer, ActionReducerMap, createSelector, MetaReducer } from '@ngrx/store';

${generateImports(entities)}
export interface RouterStateUrl {
  url: string;
  queryParams: Params;
  params: Params;
}

// ---------------------------------------
// Core State and Reducers
// ---------------------------------------

export interface AppState {
  router: fromRouter.RouterReducerState&lt;RouterStateUrl>,
  ${generateState(entities)}
}

export const reducers: ActionReducerMap&lt;AppState> = {
  router: fromRouter.routerReducer,
  ${generateReducer(entities)}
};  
  `;

  return template;
}

export const CoreStateGenerator = {
  generate
}