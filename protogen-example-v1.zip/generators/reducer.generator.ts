import { capitalize } from '../utils';

const generate = (entity, scope) => {
  const obj         = `${entity.singular}`;
  const objs        = `${entity.plural}`;
  const model       = capitalize(obj);
  const models      = capitalize(objs);

  const template = `
import { ${model} } from '@${scope}/api-interfaces';
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { Action, createReducer, on } from '@ngrx/store';

import * as ${models}Actions from './${objs}.actions';

export const ${objs.toUpperCase()}_FEATURE_KEY = '${objs}';

export interface ${models}State extends EntityState&lt;${model}> {
  selectedId?: string | number; // which ${models} record has been selected
  loaded: boolean; // has the ${models} list been loaded
  error?: string | null; // last known error (if any)
}

export interface ${models}PartialState {
  readonly [${objs.toUpperCase()}_FEATURE_KEY]: ${models}State;
}

export const ${objs}Adapter: EntityAdapter&lt;${model}> = createEntityAdapter&lt;${model}>();

export const initial${models}State: ${models}State = ${objs}Adapter.getInitialState({
  // set initial required properties
  loaded: false
});

const onFailure = (state, { error }) => ({ ...state, error});

const _${objs}Reducer = createReducer(
  initial${models}State,
  on(${models}Actions.select${model}, (state, { selectedId }) =>
    Object.assign({}, state, { selectedId })
  ),
  on(${models}Actions.resetSelected${model}, state =>
    Object.assign({}, state, { selectedId: null })
  ),
  on(${models}Actions.reset${models}, state => ${objs}Adapter.removeAll(state)),
  // Load ${objs}
  on(${models}Actions.load${models}, state => ({ ...state, loaded: false, error: null })),
  on(${models}Actions.load${models}Success, (state, { ${objs} }) =>
    ${objs}Adapter.setAll(${objs}, { ...state, loaded: true })
  ),
  on(${models}Actions.load${models}Failure, onFailure),
  // Load ${obj}
  on(${models}Actions.load${model}, state =>
    ({ ...state, loaded: false, error: null })
  ),
  on(${models}Actions.load${model}Success, (state, { ${obj} }) =>
    ${objs}Adapter.upsertOne(${obj}, { ...state, loaded: true })
  ),
  on(${models}Actions.load${model}Failure, onFailure),
  // Add ${obj}
  on(${models}Actions.create${model}Success, (state, { ${obj} }) =>
    ${objs}Adapter.addOne(${obj}, state)
  ),
  on(${models}Actions.create${model}Failure, onFailure),
  // Update ${obj}
  on(${models}Actions.update${model}Success, (state, { ${obj} }) =>
    ${objs}Adapter.updateOne({ id: ${obj}.id, changes: ${obj} }, state)
  ),
  on(${models}Actions.update${model}Failure, onFailure),
  // Delete ${obj}
  on(${models}Actions.delete${model}Success, (state, { ${obj} }) =>
    ${objs}Adapter.removeOne(${obj}.id, state)
  ),
  on(${models}Actions.delete${model}Failure, onFailure),
);

export function ${objs}Reducer(state: ${models}State | undefined, action: Action) {
  return _${objs}Reducer(state, action);
}
  `;

  return template;
}

export const ReducerGenerator = {
  generate
}
