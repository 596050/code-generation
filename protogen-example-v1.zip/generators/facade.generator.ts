import { capitalize } from '../utils';

const generate = (entity, scope) => {
  const obj         = `${entity.singular}`;
  const objs        = `${entity.plural}`;
  const model       = capitalize(obj);
  const models      = capitalize(objs);
  const modelParam  = `${obj}: ${model}`;
  const modelsParam = `${objs}: ${model}[]`;

  const template = `
import { Injectable } from '@angular/core';
import { ${model} } from '@${scope}/api-interfaces';
import { Action, ActionsSubject, select, Store } from '@ngrx/store';
import { filter } from 'rxjs/operators';

import * as ${models}Actions from './${objs}.actions';
import * as from${models} from './${objs}.reducer';
import * as ${models}Selectors from './${objs}.selectors';

@Injectable({
  providedIn: 'root'
})
export class ${models}Facade {
  loaded\$ = this.store.pipe(select(${models}Selectors.get${models}Loaded));
  all${models}\$ = this.store.pipe(select(${models}Selectors.getAll${models}));
  selected${model}\$ = this.store.pipe(select(${models}Selectors.getSelected${model}));

  mutations\$ = this.actions\$.pipe(
    filter((action: Action) =>
    action.type === ${models}Actions.create${model}({} as any).type ||
    action.type === ${models}Actions.update${model}({} as any).type ||
    action.type === ${models}Actions.delete${model}({} as any).type
    )
  );

  constructor(private store: Store<from${models}.${models}PartialState>, private actions\$: ActionsSubject) { }

  select${model}(selectedId: string) {
    this.dispatch(${models}Actions.select${model}({ selectedId }));
  }

  load${models}() {
    this.dispatch(${models}Actions.load${models}());
  }

  load${model}(${obj}Id: string) {
    this.dispatch(${models}Actions.load${model}({ ${obj}Id }));
  }

  create${model}(${obj}: ${model}) {
    this.dispatch(${models}Actions.create${model}({ ${obj} }));
  }

  update${model}(${obj}: ${model}) {
    this.dispatch(${models}Actions.update${model}({ ${obj} }));
  }

  delete${model}(${obj}: ${model}) {
    this.dispatch(${models}Actions.delete${model}({ ${obj} }));
  }

  dispatch(action: Action) {
    this.store.dispatch(action);
  }
}
  `;

  return template;
}

export const FacadeGenerator = {
  generate
}