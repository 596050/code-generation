import { capitalize } from '../utils';

const generate = (entity, scope) => {
  const obj         = `${entity.singular}`;
  const objs        = `${entity.plural}`;
  const model       = capitalize(obj);
  const models      = capitalize(objs);
  const modelParam  = `${obj}: ${model}`;
  const modelsParam = `${objs}: ${model}[]`;

  const template = `
import { Injectable } from '@angular/core';
import { ${models}Service } from '@briebug-academy/core-data';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { fetch, pessimisticUpdate } from '@nrwl/angular';
import { map } from 'rxjs/operators';
import * as ${models}Actions from './${objs}.actions';

@Injectable()
export class ${models}Effects {
  @Effect() load${models}\$ = this.actions\$.pipe(
    ofType(${models}Actions.load${models}),
    fetch({
      run: (action) => this.${objs}Service.all().pipe(
        map((${objs}) => ${models}Actions.load${models}Success({ ${objs} }))
      ),
      onError: (action, error) => ${models}Actions.load${models}Failure({ error })
    })
  );

  @Effect() load${model}\$ = this.actions\$.pipe(
    ofType(${models}Actions.load${model}),
    fetch({
      run: (action) => this.${objs}Service.findById(action.${obj}Id).pipe(
        map((${obj}) => ${models}Actions.load${model}Success({ ${obj} }))
      ),
      onError: (action, error) => ${models}Actions.load${model}Failure({ error })
    })
  );

  @Effect() create${model}\$ = this.actions\$.pipe(
    ofType(${models}Actions.create${model}),
    pessimisticUpdate({
      run: (action) => this.${objs}Service.create(action.${obj}).pipe(
        map((${obj}) => ${models}Actions.create${model}Success({ ${obj} }))
      ),
      onError: (action, error) => ${models}Actions.create${model}Failure({ error })
    })
  );

  @Effect() update${model}\$ = this.actions\$.pipe(
    ofType(${models}Actions.update${model}),
    pessimisticUpdate({
      run: (action) => this.${objs}Service.update(action.${obj}).pipe(
        map((${obj}) => ${models}Actions.update${model}Success({ ${obj} }))
      ),
      onError: (action, error) => ${models}Actions.update${model}Failure({ error })
    })
  );

  @Effect() delete${model}\$ = this.actions\$.pipe(
    ofType(${models}Actions.delete${model}),
    pessimisticUpdate({
      run: (action) => this.${objs}Service.delete(action.${obj}.id).pipe(
        map((${obj}) => ${models}Actions.delete${model}Success({ ${obj} })),
      ),
      onError: (action, error) => ${models}Actions.delete${model}Failure({ error })
    })
  );

  constructor(
    private actions\$: Actions,
    private ${objs}Service: ${models}Service
  ) {}
}
  `;

  return template;
}

export const EffectsGenerator = {
  generate
}