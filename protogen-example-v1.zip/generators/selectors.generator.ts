import { capitalize } from '../utils';

const generate = (entity, scope) => {
  const obj         = `${entity.singular}`;
  const objs        = `${entity.plural}`;
  const model       = capitalize(obj);
  const models      = capitalize(objs);
  const modelParam  = `${obj}: ${model}`;
  const modelsParam = `${objs}: ${model}[]`;

  const template = `
import { createFeatureSelector, createSelector } from '@ngrx/store';
import {
  ${models.toUpperCase()}_FEATURE_KEY,
  ${models}State,
  ${objs}Adapter
} from './${objs}.reducer';

// Lookup the '${models}' feature state managed by NgRx
export const get${models}State = createFeatureSelector<
  ${models}State
>(${models.toUpperCase()}_FEATURE_KEY);

const { selectAll, selectEntities } = ${objs}Adapter.getSelectors();

export const get${models}Loaded = createSelector(
  get${models}State,
  (state: ${models}State) => state.loaded
);

export const get${models}Error = createSelector(
  get${models}State,
  (state: ${models}State) => state.error
);

export const getAll${models} = createSelector(
  get${models}State,
  (state: ${models}State) => selectAll(state)
);

export const get${models}Entities = createSelector(
  get${models}State,
  (state: ${models}State) => selectEntities(state)
);

export const getSelected${model}Id = createSelector(
  get${models}State,
  (state: ${models}State) => state.selectedId
);

export const getSelected${model} = createSelector(
  get${models}Entities,
  getSelected${model}Id,
  (entities, selectedId) => selectedId && entities[selectedId]
);
  `;

  return template;
}

export const SelectorsGenerator = {
  generate
}