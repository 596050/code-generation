import { capitalize } from '../utils';

const generateRefs = (entities) => {
  let output = '';
  entities.forEach(entity => output += `\t\t${capitalize(entity.plural)}Effects,\n`)
  return output;
}

const generateImports = (entities) => {
  let output = '';
  entities.forEach(entity => 
    output += `import { ${capitalize(entity.plural)}Effects } from './${entity.plural}/${entity.plural}.effects';\n`)
  return output;
}

const generate = (entities, scope) => {
  const template = `
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { RootStoreConfig, StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { reducers } from '.';

${generateImports(entities)}
const STORE_NAME = '${scope}-store';
const storeConfig: RootStoreConfig&lt;any> = {
  runtimeChecks: {
    strictActionImmutability: true,
    strictActionSerializability: true,
    strictStateImmutability: true,
    strictStateSerializability: true
  }
};

@NgModule({
  imports: [
    CommonModule,
    StoreModule.forRoot(reducers, storeConfig),
    EffectsModule.forRoot([
${generateRefs(entities)}
    ]),
    StoreDevtoolsModule.instrument({ maxAge: 25, name: STORE_NAME }),
    StoreRouterConnectingModule.forRoot({stateKey: 'router'}),
  ]
})
export class CoreStateModule { }
  `;

  return template;
}

export const CoreStateModuleGenerator = {
  generate
}