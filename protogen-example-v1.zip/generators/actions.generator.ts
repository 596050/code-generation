import { capitalize } from '../utils';

const generate = (entity, scope) => {
  const obj         = `${entity.singular}`;
  const objs        = `${entity.plural}`;
  const model       = capitalize(obj);
  const models      = capitalize(objs);
  const modelParam  = `${obj}: ${model}`;
  const modelsParam = `${objs}: ${model}[]`;

  const template = `
import { ${model} } from '@${scope}/api-interfaces';
import { createAction, props } from '@ngrx/store';

export const resetSelected${model} = createAction('[${models}] Reset Selected ${model}');
export const reset${models} = createAction('[${models}] Reset ${models}');

// Select ${model}
export const select${model} = createAction(
  '[${models}] Select ${model}',
  props<{ selectedId: string }>()
);

// Load ${models}
export const load${models} = createAction('[${models}] Load ${models}');

export const load${models}Success = createAction(
  '[${models}] Load ${models} Success',
  props<{ ${modelsParam} }>()
);

export const load${models}Failure = createAction(
  '[${models}] Load ${models} Failure',
  props<{ error: any }>()
);

// Load ${model}
export const load${model} = createAction(
  '[${models}] Load ${model}',
  props<{ ${obj}Id: string }>()
);

export const load${model}Success = createAction(
  '[${models}] Load ${model} Success',
  props<{ ${modelParam} }>()
);

export const load${model}Failure = createAction(
  '[${models}] Load ${model} Failure',
  props<{ error: any }>()
);

// Create ${model}
export const create${model} = createAction(
  '[${models}] Create ${model}',
  props<{ ${modelParam} }>()
);

export const create${model}Success = createAction(
  '[${models}] Create ${model} Success',
  props<{ ${modelParam} }>()
);

export const create${model}Failure = createAction(
  '[${models}] Create ${model} Failure',
  props<{ error: any }>()
);

// Update ${model}
export const update${model} = createAction(
  '[${models}] Update ${model}',
  props<{ ${modelParam} }>()
);

export const update${model}Success = createAction(
  '[${models}] Update ${model} Success',
  props<{ ${modelParam} }>()
);

export const update${model}Failure = createAction(
  '[${models}] Update ${model} Failure',
  props<{ error: any }>()
);

// Delete ${model}
export const delete${model} = createAction(
  '[${models}] Delete ${model}',
  props<{ ${modelParam} }>()
);

export const delete${model}Cancelled = createAction('[${models}] Delete ${model} Cancelled');

export const delete${model}Success = createAction(
  '[${models}] Delete ${model} Success',
  props<{ ${modelParam} }>()
);

export const delete${model}Failure = createAction(
  '[${models}] Delete ${model} Failure',
  props<{ error: any }>()
);
`;

  return template;
}

export const ActionsGenerator = {
  generate
}