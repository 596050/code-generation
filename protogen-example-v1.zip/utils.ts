import { Workspace, Generator } from './models';

export const capitalize = (s) => {
  if (typeof s !== 'string') return ''
  return s.charAt(0).toUpperCase() + s.slice(1)
}

export const prettyPrint = (id, collection, language) => {
  let output = '';
  collection.forEach((obj, index) => {
    output += `<pre><code id="${id}-${index}" class="language-${language}">${obj}</code></pre>`;
    output += `<button class="btn" data-clipboard-target="#${id}-${index}">Copy</button>`;
  })
  return output;
}

export const renderMessage = id => `<h2>GENERATED ${id.split('-').join(' ').toUpperCase()}</h2>`;

export const render = (id, collection, language, logging) => {
  const div: HTMLElement = document.createElement('div');
  div.setAttribute('id', id);
  document.body.appendChild(div)
	div.innerHTML = `
${logging ? renderMessage(id) : ''}
${prettyPrint(id, collection, language)}
`;
}

export const generate = (workspace: Workspace, generator: Generator) => {
	return workspace.entities.map(entity => generator.generate(entity, workspace.scope));
}