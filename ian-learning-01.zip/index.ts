// Import stylesheets
import './style.css';

// BASIC
// var drawCats = function (howManyTimes) {
//   for(var i = 0; i < howManyTimes; ++i) {
//     console.log(i + ' =^.^=');
//   }
// };

// MEDIUM
const drawCats = (howManyTimes) => {
  for (let i = 0; i < howManyTimes; ++i) {
    console.log(`${i} =^.^=`);
  }
};

// ADVANCED
// const drawCats = (howManyTimes) => {
//   Array.apply(null, Array(howManyTimes)).forEach((_, i) =>
//     console.log(`${i} =^.^=`)
//   );
// };

drawCats(10);

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `<h1>TypeScript Starter</h1>`;
