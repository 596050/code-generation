import './style.css';
import 'highlight.js/styles/tomorrow-night-bright.css';

import hljs from 'highlight.js';
import typescript from 'highlight.js/lib/languages/typescript';

hljs.registerLanguage('typescript', typescript);

const faker = require('faker');
const moment = require('moment');

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  title: string;
  notes: string;
  progress: number;
  active: boolean;
  startDate: string;
}

interface Book {
  id: string;
  title: string;
  notes: string;
}

const bookProps = ['id', 'title', 'notes'];

const userProps = [
  'id',
  'firstName',
  'lastName',
  'email',
  'title',
  'notes',
  'progress',
  'active',
  'startDate',
];

const getRandomInt = (min, max) => faker.datatype.number({ min, max });

const getRandomDate = () =>
  moment().subtract(getRandomInt(3650, 7300), 'days').format('MM/DD/YYYY');

const generators = {
  id: { func: faker.datatype.uuid },
  firstName: { func: faker.name.firstName },
  lastName: { func: faker.name.lastName },
  email: { func: faker.internet.email },
  title: { func: faker.random.words, args: 3 },
  notes: { func: faker.lorem.words, args: 5 },
  progress: { func: faker.datatype.number, args: { min: 0, max: 100 } },
  active: { func: faker.datatype.boolean },
  startDate: { func: getRandomDate },
};

const generate = (props, generators) =>
  props.reduce((obj, prop) => {
    const generator = generators[prop];
    obj[prop] = generator.func(generator.args);
    return obj;
  }, {});

const generateUsers = () => {
  const minUsers = 3;
  const maxUsers = 12;
  const len = getRandomInt(minUsers, maxUsers);
  const users = Array.apply(null, Array(len)).map(() =>
    generate(userProps, generators)
  );
  return users;
};

const generateBooks = () => {
  const min = 10;
  const max = 10000;
  const len = getRandomInt(min, max);
  const books = Array.apply(null, Array(len)).map(() =>
    generate(bookProps, generators)
  );
  return books;
};

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `
<h2>Mock API</h2>
<pre>
<code class="language-typescript">
${JSON.stringify(generateUsers(), null, 2)}
</code> 
</pre>
<pre>
<code class="language-typescript">
${JSON.stringify(generateBooks(), null, 2)}
</code> 
</pre>
`;

hljs.highlightAll();
