import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormlyFormOptions, FormlyFieldConfig } from '@ngx-formly/core';

@Component({
  selector: 'formly-app-example',
  templateUrl: './app.component.html',
})
export class AppComponent {
  form = new FormGroup({});
  model: any = {};
  options: FormlyFormOptions = {};
  fields: FormlyFieldConfig[] = [
    {
      key: 'Radio',
      type: 'radio',
      templateOptions: {
        label: 'Refactoring Legacy Code',
        placeholder: 'Refactoring Legacy Code',
        description:
          'How confident are you that you can take old (and probably less-than-ideal) code and apply best practices to make it better?',
        required: true,
        options: [
          { value: 0, label: '0 - No Skill' },
          { value: 1, label: '1 - Basic Knowledge' },
          { value: 2, label: '2 - Can Perform Basic Tasks' },
          { value: 3, label: '3 - Can Perform Advanced Tasks' },
          { value: 4, label: '4 - Can Teach Advanced Tasks' },
        ],
      },
    },
  ];
}

/**  Copyright 2018 Google Inc. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */
