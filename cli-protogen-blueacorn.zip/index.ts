// Import stylesheets
import './style.css';

let output = '';

const ORG = 'blueacorn';

const DATA_MODULE = 'core-data';
const STATE_MODULE = 'core-state';
const AMPLIFY_MODULE = 'aws-amplify';
const GRAPHQL_MODULE = 'apollo-graphql';
const MATERIAL_MODULE = 'material';
const LOGIN_MODULE = 'ui-login';
const TOOLBAR_MODULE = 'ui-toolbar';
const UPLOADER_MODULE = 'ui-uploader'

const libs = [
  DATA_MODULE,
  STATE_MODULE,
  AMPLIFY_MODULE,
  GRAPHQL_MODULE,
  MATERIAL_MODULE,
  LOGIN_MODULE,
  TOOLBAR_MODULE,
  UPLOADER_MODULE,
];

const entities = [
	{ plural: 'agents', singular: 'agent'},
	{ plural: 'applicants', singular: 'applicant'},
	{ plural: 'applications', singular: 'application'},
	{ plural: 'documents', singular: 'document'},
	{ plural: 'messages', singular: 'message'},
	{ plural: 'questions', singular: 'question'},
	{ plural: 'workers', singular: 'worker'}
];

// -------------------------------------------------------------------
// SERVICE LAYER
// -------------------------------------------------------------------
const generateCoreLib = (lib, suffix) => output += `\n nx g lib ${lib} ${suffix}`;

const generateService = entity => {
  output += `\n ng g s services/${entity.plural}/${entity.plural} \\
    --project=${DATA_MODULE} && \\`;
}

const generateNgRx = entity => {
  output += `\n ng g @nrwl/angular:ngrx ${entity.plural} \\
    --module=libs/${STATE_MODULE}/src/lib/${STATE_MODULE}.module.ts \\
    --directory ${entity.plural} \\
    --defaults \\
    --facade && \\`;
};

const generateDataLayer = entities => {
	entities.forEach(entity => generateService(entity));
};

const generateStateLayer = entities => {
	entities.forEach(entity => generateNgRx(entity));
};

// -------------------------------------------------------------------
// COMPONENT LAYER
// -------------------------------------------------------------------
const generateContainerComponent = (entity, suffix) => {
  output += `\n ng g c ${entity.plural} ${suffix}`;
};

const generateListComponent = (entity, suffix) => {
  output += `\n ng g c ${entity.plural}/${entity.plural}-list ${suffix}`;
};

const generateDetailsComponent = (entity, suffix) => {
  output += `\n ng g c ${entity.plural}/${entity.singular}-details ${suffix}`;
};

const generateLibComponent = (component, project, suffix) => {
  output += `\n ng g c ${component} --project ${project} ${suffix}`;
}

const generateComponentLayer = (entities, suffix) => {
  entities.forEach(entity => {
    generateContainerComponent(entity, suffix);
    generateListComponent(entity, suffix);
    generateDetailsComponent(entity, suffix);
  })
};

// -------------------------------------------------------------------
// THE MAGIC
// -------------------------------------------------------------------

const libSuffix = '--style=scss && \\';
const componentSuffix = '-m app.module.ts --style=scss && \\';

const logMessage = message => output += `\n\n <strong>${message}</strong> \n`;
const generateWorkspace = org => output += `\n npx create-nx-workspace@latest ${org}`;
const generateLibs = (libs, suffix) => libs.forEach(lib => generateCoreLib(lib, suffix));

logMessage('STEP 00: Generate workspace');
generateWorkspace(ORG);

logMessage('STEP 01: Generate libs');
generateLibs(libs, libSuffix);

logMessage('STEP 02: Generate remote data services');
generateDataLayer(entities);

logMessage('STEP 03: Generate ngrx services');
generateStateLayer(entities);

logMessage('STEP 04: Generate components for main features');
generateComponentLayer(entities, componentSuffix);

logMessage('STEP 05: Generate speciality components for libs');
generateLibComponent('login', 'ui-login', libSuffix);
generateLibComponent('toolbar', 'ui-toolbar', libSuffix);
generateLibComponent('upload', 'ui-uploader', libSuffix);
generateLibComponent('upload-item', 'ui-uploader', libSuffix);

generateService({single: 'upload', plural: 'upload'});
generateService({single: 'aws-amplify', plural: 'aws-amplify'});
generateService({single: 'config', plural: 'config'});
generateService({single: 'notification', plural: 'notifications'});

generateContainerComponent({plural: 'home'}, componentSuffix);
generateContainerComponent({plural: 'courses/courses-card'}, componentSuffix);

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `<pre>${output}</pre>`;