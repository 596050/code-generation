// Import stylesheets
import './style.css';

const faker = require('faker');
const moment = require('moment');

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  title: string;
  notes: string;
  progress: number;
  active: boolean;
  startDate: string;
}

const userProps = [
  'id',
  'firstName',
  'lastName',
  'email',
  'title',
  'notes',
  'progress',
  'active',
  'startDate',
];

const getRandomInt = (min, max) => faker.datatype.number({ min, max });

const getRandomDate = () =>
  moment().subtract(getRandomInt(3650, 7300), 'days').format('MM/DD/YYYY');

const generators = {
  id: { func: faker.datatype.uuid },
  firstName: { func: faker.name.firstName },
  lastName: { func: faker.name.lastName },
  email: { func: faker.internet.email },
  title: { func: faker.random.words, args: 3 },
  notes: { func: faker.lorem.words, args: 5 },
  progress: { func: faker.datatype.number, args: { min: 0, max: 100 } },
  active: { func: faker.datatype.boolean },
  startDate: { func: getRandomDate },
};

const generate = (props, generators) => {
  const obj = {};
  props.forEach((prop) => {
    const generator = generators[prop];
    obj[prop] = generator.func(generator.args);
  });
  return obj;
};

const generateUsers = () => {
  const minUsers = 3;
  const maxUsers = 12;
  const len = getRandomInt(minUsers, maxUsers);
  const users = Array.apply(null, Array(len)).map(() =>
    generate(userProps, generators)
  );
  return users;
};

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `<pre>${JSON.stringify(generateUsers(), null, 2)}</pre>`;
