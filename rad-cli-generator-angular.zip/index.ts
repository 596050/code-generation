import './style.css';
import 'highlight.js/styles/tomorrow-night-bright.css';

import hljs from 'highlight.js';
import bash from 'highlight.js/lib/languages/bash';

hljs.registerLanguage('bash', bash);

export interface Workspace {
  title: string;
  description?: string;
  config: Config;
  cli: CLI;
  schemas: Schema[];
}

export interface Config {
  name: string;
  application: string;
  scope: string;
  type: string;
}

export interface CLI {
  packages?: string[];
  dependencies?: string[];
  libs?: string[];
  detached?: {
    [key: string]: Schema;
  };
  suffixes: {
    [key: string]: string;
  };
  steps: Step[];
}

export interface Step {
  key: string;
  params: any;
}

export interface Schema {
  model: string;
  modelPlural: string;
}

const DATA_MODULE = 'core-data';
const STATE_MODULE = 'core-state';
const MATERIAL_MODULE = 'material';
const LOGIN_MODULE = 'ui-login';

// -------------------------------------------------------------------
// FUNCTIONALITY
// -------------------------------------------------------------------

const workspace = ({ config }) =>
  `npx create-nx-workspace@latest ${config.name} \\
  --appName=${config.application} \\
  --preset=${config.type} \\
  --npmScope=${config.scope} \\
  --nx-cloud=false \\
  --linter=eslint \\
  --style=scss && \\
cd ${config.name}/ && \\\n`;

const packages = ({ cli }) =>
  cli.packages.reduce((code, dependency) => {
    return (code += `npm i ${dependency} --force && \\\n`);
  }, '');

const dependencies = ({ cli }) =>
  cli.dependencies.reduce((code, dependency) => {
    return (code += `npx nx g ${dependency}:ng-add --no-interactive && \\\n`);
  }, '');

const libs = ({ cli }) =>
  cli.libs.reduce((code, lib) => {
    return (code += `nx g lib ${lib} ${cli.suffixes.lib} && \\\n`);
  }, '');

const state = ({ schemas }) =>
  schemas.reduce((code, schema) => {
    return (code += `nx g @nrwl/angular:ngrx ${schema.modelPlural} \\
    --module=libs/${STATE_MODULE}/src/lib/${STATE_MODULE}.module.ts \\
    --directory ${schema.modelPlural} \\
    --no-interactive \\
    --facade && \\\n`);
  }, '');

const services = ({ schemas }) =>
  schemas.reduce((code, schema) => {
    return (code += `nx g s services/${schema.modelPlural}/${schema.modelPlural} --project=${DATA_MODULE} && \\\n`);
  }, '');

const homeComponent = ({ cli }) =>
  containerComponent({ schema: cli.detached.home, suffix: cli.suffixes.home });

const containerComponent = ({ schema, suffix = '' }) =>
  `nx g c ${schema.modelPlural} ${suffix} && \\\n`;

const listComponent = ({ schema, suffix = '' }) =>
  `nx g c ${schema.modelPlural}/${schema.modelPlural}-list ${suffix} && \\\n`;

const detailsComponent = ({ schema, suffix = '' }) =>
  `nx g c ${schema.modelPlural}/${schema.model}-details ${suffix} && \\\n`;

const componentLayer = ({ cli, schemas }) =>
  schemas.reduce((code, schema) => {
    code += containerComponent({ schema, suffix: cli.suffixes.component });
    code += listComponent({ schema, suffix: cli.suffixes.component });
    code += detailsComponent({ schema, suffix: cli.suffixes.component });
    return code;
  }, '');

const nest = ({ schemas }) =>
  schemas.reduce((code, schema) => {
    return (code += `nx g @nestjs/schematics:resource ${schema.modelPlural} \\
    --project api \\
    --no-interactive && \\\n`);
  }, '');

const routingModule = () =>
  `nx g m routing --flat=true -m=app.module.ts && \\\n`;

const stateContainer = () => `touch libs/core-state/src/lib/index.ts && \\\n`;

const jsonServer = () => `mkdir server && touch server/db.json && \\\n`;

const start = () =>
  `npx concurrently "nx serve --port 4300 --open" "npm start api"`;

// prettier-ignore
const stepMap = {
  'workspace': workspace,
  'packages': packages,
  'dependencies': dependencies,
  'libs': libs,
  'state': state,
  'services': services,
  'componentLayer': componentLayer,
  'homeComponent': homeComponent,
  'stateContainer': stateContainer,
  'routingModule': routingModule,
  'nest': nest,
  'jsonServer': jsonServer,
  'start': start,
}

const generate = (steps: Step[]) =>
  steps.reduce((code, { key, params }) => {
    code += stepMap[key](params);
    return code;
  }, '');

// -------------------------------------------------------------------
// DATA
// -------------------------------------------------------------------

const userSchema: Schema = {
  model: 'user',
  modelPlural: 'users',
};

const courseSchema: Schema = {
  model: 'course',
  modelPlural: 'courses',
};

const lessonSchema: Schema = {
  model: 'lesson',
  modelPlural: 'lessons',
};

const assignmentSchema: Schema = {
  model: 'assignment',
  modelPlural: 'assignments',
};

const feedbackSchema: Schema = {
  model: 'feedback',
  modelPlural: 'feedback',
};

const homeSchema: Schema = {
  model: 'home',
  modelPlural: 'home',
};

const loginSchema: Schema = {
  model: 'login',
  modelPlural: 'login',
};

const schemas: Schema[] = [
  userSchema,
  courseSchema,
  lessonSchema,
  assignmentSchema,
  feedbackSchema,
];

const suffixes = {
  style: `--style=scss`,
  lib: `--parent-module=apps/dashboard/src/app/app.module.ts`,
  component: `-m app.module.ts --style=scss`,
};

const cli: CLI = {
  packages: [
    '-D json-server',
    '-D concurrently',
    '@angular/material',
    '@ngrx/store',
  ],
  dependencies: ['@ngrx/store', '@angular/material'],
  libs: [DATA_MODULE, STATE_MODULE, MATERIAL_MODULE, LOGIN_MODULE],
  detached: {
    home: homeSchema,
    login: loginSchema,
  },
  suffixes,
  steps: [],
};

const config: Config = {
  name: 'workshop',
  application: 'dashboard',
  scope: 'proto',
  type: 'angular-nest',
};

const demoSpace: Workspace = {
  title: 'Reactive Angular Application',
  config,
  cli,
  schemas,
};

cli.steps = [
  { key: 'workspace', params: demoSpace },
  { key: 'packages', params: demoSpace },
  { key: 'dependencies', params: demoSpace },
  { key: 'libs', params: demoSpace },
  { key: 'state', params: demoSpace },
  { key: 'services', params: demoSpace },
  { key: 'componentLayer', params: demoSpace },
  { key: 'homeComponent', params: demoSpace },
  { key: 'stateContainer', params: demoSpace },
  { key: 'routingModule', params: demoSpace },
  { key: 'nest', params: demoSpace },
  { key: 'jsonServer', params: demoSpace },
  { key: 'start', params: demoSpace },
];

const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `
<h2>CLI Ludicrous Mode</h2>
<pre>
<code class="language-bash">${generate(demoSpace.cli.steps)}</code>  
</pre>
`;

hljs.highlightAll();
