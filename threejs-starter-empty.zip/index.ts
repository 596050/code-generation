import * as THREE from 'three';
import { gsap } from 'gsap';

import './style.css';

enum Colors {
  white = 0xffffff,
  grey = 0x333333,
  blue = 0x9eaeff,
}

// -------------------------------------------------------------------
// UTILITIES
// -------------------------------------------------------------------

const degreesToRadians = (degrees) => {
  return degrees * (Math.PI / 180);
};

const sizes = {
  width: window.innerWidth,
  height: window.innerHeight,
};

const center = (group) => {
  new THREE.Box3()
    .setFromObject(group)
    .getCenter(group.position)
    .multiplyScalar(-1);
  scene.add(group);
};

const random = (min, max, float = false) => {
  const val = Math.random() * (max - min) + min;

  if (float) {
    return val;
  }

  return Math.floor(val);
};

const isEvenOrOdd = (i) => (i % 2 === 0 ? 1 : -1);

// -------------------------------------------------------------------
// SETUP
// -------------------------------------------------------------------

/*
Setting up a 3JS scene requires a few key components

1. select the element you want to render your scene in
2. create a scene
3. create a renderer
4. create a camera
5. create a light
*/

const cameraConfig = {
  fov: 75,
  aspect: sizes.width / sizes.height,
  near: 0.1,
  far: 1000,
  position: {
    z: 5,
  },
};

// SCENE
const canvas = document.querySelector('[data-canvas]');
const scene = new THREE.Scene();

// RENDERER
const renderer = new THREE.WebGLRenderer({ canvas });

// CAMERA
const camera = new THREE.PerspectiveCamera(
  cameraConfig.fov,
  cameraConfig.aspect,
  cameraConfig.near,
  cameraConfig.far
);
camera.position.z = cameraConfig.position.z;
scene.add(camera);

// LIGHTING
const lightAmbient = new THREE.AmbientLight(Colors.blue, 0.2);
scene.add(lightAmbient);

const lightDirectional = new THREE.DirectionalLight(Colors.white, 1);
scene.add(lightDirectional);

lightDirectional.position.set(5, 5, 5);

// -------------------------------------------------------------------
// BOX
// -------------------------------------------------------------------

const boxDims = {
  width: 1,
  height: 1,
  depth: 1,
};

class Box {
  props = {
    x: 0,
    y: -1,
    z: 0,
    angle: 0,
  };

  group;
  body;

  hue;
  material;
  lightness;

  constructor(private scene, params) {
    this.props = { ...this.props, ...params };
    this.group = new THREE.Group();
    this.scene.add(this.group);

    this.initColors();
    this.initBody();
    this.positionBody();
  }

  initBody() {
    const geometry = new THREE.BoxGeometry(
      boxDims.width,
      boxDims.height,
      boxDims.depth
    );
    this.body = new THREE.Mesh(geometry, this.material);
    this.group.add(this.body);
  }

  initColors() {
    this.hue = random(0, 360);
    this.material = new THREE.MeshLambertMaterial({
      color: `hsl(${this.hue}, 85%, 50%)`,
    });
  }

  positionBody() {
    this.group.rotation.y = this.props.angle;
    this.group.rotation.x = this.props.angle;
  }
}

const box = new Box(scene, {
  angle: degreesToRadians(45),
});

center(box.group);

// -------------------------------------------------------------------
// LOGIC
// -------------------------------------------------------------------

const render = (renderer, scene, camera) => {
  renderer.setSize(sizes.width, sizes.height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.render(scene, camera);
};

window.addEventListener('resize', () => {
  // Update sizes
  sizes.width = window.innerWidth;
  sizes.height = window.innerHeight;

  // Update camera
  camera.aspect = sizes.width / sizes.height;
  camera.updateProjectionMatrix();

  // Update renderer
  render(renderer, scene, camera);
});

render(renderer, scene, camera);
