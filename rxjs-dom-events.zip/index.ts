// Import stylesheets
import './style.css';

import { fromEvent } from 'rxjs';
import { map, scan } from 'rxjs/operators';

const appDiv: HTMLElement = document.getElementById('app');
const logEvents = events => {
    appDiv.innerHTML = `<pre>${JSON.stringify(events, null, 2)}<pre>`;
}

const stream$ = fromEvent(document, 'click');

// -------------------------------------------------------------------
// What effect does changing the event type have?
// -------------------------------------------------------------------
// const stream$ = fromEvent(document, 'mouseover');
// const stream$ = fromEvent(document, 'mousemove');

// -------------------------------------------------------------------
// V1: Capturing and handling the event output 
// -------------------------------------------------------------------
// let events = [];
// stream$
//   .subscribe((event: MouseEvent) => {
//     events = [...events, {x: event.x, y: event.y}]; // Nested logic
//     logEvents(events);
//   });

// -------------------------------------------------------------------
// V2: Transformation logic is now in the stream
// -------------------------------------------------------------------
// let events = [];
// stream$
//   .pipe(
//     map((event: MouseEvent) => ({x: event.x, y: event.y}))
//   )
//   .subscribe( event => {
//     events = [...events, event]; // Hidden state
//     logEvents(events);
//   });

// -------------------------------------------------------------------
// V3: State is now entirely encapsulated in the stream
// -------------------------------------------------------------------
// stream$
//   .pipe(
//     map((event: MouseEvent) => ({x: event.x, y: event.y})),
//     scan((curr, value) => [...curr, value], [])
//   )
//   .subscribe(events => logEvents(events)); // Verbose

// -------------------------------------------------------------------
// V4: Subscribe is now a pure pass through function
// -------------------------------------------------------------------
// stream$
//   .pipe(
//     map((event: MouseEvent) => ({x: event.x, y: event.y})),
//     scan((curr, value) => [...curr, value], [])
//   ) 
//   .subscribe(logEvents); // Achievement unlocked! Zero effort input FTW!

// -------------------------------------------------------------------
// V5: Variation with unsubscribe
// -------------------------------------------------------------------
const events$ = fromEvent(document, 'click')
  .pipe(
    map((event: MouseEvent) => ({x: event.x, y: event.y})),
    scan((curr, value) => [...curr, value], [])
  );

const subscription = events$.subscribe(logEvents);
const destroy = () => subscription.unsubscribe();