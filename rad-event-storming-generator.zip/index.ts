import './style.css';
import 'highlight.js/styles/tomorrow-night-bright.css';

import hljs from 'highlight.js';
import typescript from 'highlight.js/lib/languages/typescript';

hljs.registerLanguage('typescript', typescript);

import {
  ActionsGenerator,
  EffectsGenerator,
  ReducerLogicGenerator,
  ReducerGenerator,
} from './generators';
import { Config, Schema, Generator } from './meta-models';
import { buildNameVariations } from './engines/name-variations';

export const config: Config = {
  name: 'Workshop Config',
  application: 'dashboard',
  scope: 'acme',
};

export const schema: Schema = {
  model: 'game',
  modelPlural: 'games',
};

const events = ['play', 'pause', 'stop', 'reset', 'exit'];

const generateScript = (entity, events) =>
  events.reduce((code, event) => {
    code += `I should be able to ${event} a ${entity.model}\n`;
    return code;
  }, '');

const generateCode = (
  generator: Generator,
  events: string[],
  entity: Schema,
  config: Config
) =>
  events.reduce((code, event) => {
    code += generator.generate(event, entity, config).template;
    return code;
  }, '');

const generateFullReducer = (
  events: string[],
  entity: Schema,
  config: Config
) => {
  const logic = generateCode(ReducerLogicGenerator, events, entity, config);
  const reducer = ReducerGenerator.generate(logic, entity, config);
  return reducer.template;
};

const appDiv: HTMLElement = document.getElementById('app');

appDiv.innerHTML = `
<h3>Event Storming</h3>
<pre>
<code class="language-typescript">
// What is the thing?
// What can you do with it?
${generateScript(schema, events)}
</code> 
</pre>`;

appDiv.innerHTML += `<h3>Events</h3>
<pre><code class="language-typescript">
// What are the events that the thing can initiate?
// What are the commands you can issue to the thing?
// What would happen if you addeded another event to the collection?
${JSON.stringify(events, null, 2)}
</code></pre>`;

appDiv.innerHTML += `<h3>Model Name Variations</h3>
<pre><code class="language-typescript">
// What are some naming variations of the thing.
// You know... for like... code
${JSON.stringify(buildNameVariations(schema), null, 2)}
</code></pre>`;

appDiv.innerHTML += `<h3>Generated Actions</h3>
<pre><code class="language-typescript">
${generateCode(ActionsGenerator, events, schema, config)}
</code></pre>`;

appDiv.innerHTML += `<h3>Generated Effects</h3>
<pre><code class="language-typescript">
${generateCode(EffectsGenerator, events, schema, config)}
</code></pre>`;

appDiv.innerHTML += `<h3>Generated Reducer Logic</h3>
<pre><code class="language-typescript">
${generateCode(ReducerLogicGenerator, events, schema, config)}
</code></pre>`;

appDiv.innerHTML += `<h3>Generated Full Reducer</h3>
<pre><code class="language-typescript">
${generateFullReducer(events, schema, config)}
</code></pre>`;

hljs.highlightAll();
