// Import stylesheets
import "./style.css";

enum PlayerPostion {
  FirstBase = "FirstBase",
  SecondBase = "SecondBase",
  ShortStop = "ShortStop",
  ThirdBase = "ThirdBase",
  Pitcher = "Pitcher",
  Catcher = "Catcher",
  LeftField = "LeftField",
  CenterField = "CenterField",
  RightField = "RightField"
}

enum AtBat {
  hit = "hit",
  out = "out",
  walk = "walk"
}

interface Player {
  firstName: string;
  lastName: string;
  position: PlayerPostion;
  atBats: AtBat[];
  battingAverage: string;
}

const atThePlate = (player: Player, event: AtBat) => {
  player.atBats = [...player.atBats, event];
};

const countHits = (atBats: AtBat[]) => {
 return atBats.reduce((hits, atBat) => (atBat === AtBat.hit ? hits + 1 : hits), 0);
}

const getValidAtBats = (atBats: AtBat[]) => atBats.filter(
  (atBat: AtBat) => atBat !== AtBat.walk
)

const formatAvg = (avg) => {
  const fixedAvg = avg.toFixed(3);
  return fixedAvg.replace(/^0+/, '');
}

const calculateBattingAverage = (player: Player) => {
  const validAtBats = getValidAtBats(player.atBats);
  const hits = countHits(validAtBats);
  const avg = hits / validAtBats.length;
  return formatAvg(avg);
};

// MIKE TROUT
const mikeTrout: Player = {
  firstName: 'Mike',
  lastName: 'Trout',
  position: PlayerPostion.CenterField,
  atBats: [],
  battingAverage: '0',
};

atThePlate(mikeTrout, AtBat.hit);
atThePlate(mikeTrout, AtBat.hit);
atThePlate(mikeTrout, AtBat.walk);
atThePlate(mikeTrout, AtBat.out);
atThePlate(mikeTrout, AtBat.hit);
atThePlate(mikeTrout, AtBat.out);
atThePlate(mikeTrout, AtBat.hit);
atThePlate(mikeTrout, AtBat.out);

mikeTrout.battingAverage = calculateBattingAverage(mikeTrout);

// JOEY GALLO
const joeyGallo: Player = {
  firstName: 'Joey',
  lastName: 'Gallo',
  position: PlayerPostion.RightField,
  atBats: [],
  battingAverage: '0',
}

atThePlate(joeyGallo, AtBat.out);
atThePlate(joeyGallo, AtBat.out);
atThePlate(joeyGallo, AtBat.out);
atThePlate(joeyGallo, AtBat.hit);
atThePlate(joeyGallo, AtBat.hit);
atThePlate(joeyGallo, AtBat.out);
atThePlate(joeyGallo, AtBat.out);

joeyGallo.battingAverage = calculateBattingAverage(joeyGallo);

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById("app");
appDiv.innerHTML = `<pre>
  <h3>${JSON.stringify(joeyGallo, null, 2)}</h3>
  <h3>${JSON.stringify(mikeTrout, null, 2)}</h3>
<pre>`;
