// Import stylesheets
import './style.css';

interface Client {
  id: string;
  firstName: string;
  lastName: string;
  company: string;
}

interface ClientsState {
  clients: Client[];
  currentClient: Client;
}

interface Project {
  id: string;
  title: string;
  description: string;
  completed: boolean;
}

interface ProjectsState {
  projects: Project[];
  currentProject: Project;
}

const project: Project = {
  id: '1',
  title: 'Super Project',
  description: 'All my wildest dreams are coming true!!!',
  completed: false,
}

const projects: Project[] = [
  project
]

const initialProjectsState: ProjectsState = {
  projects,
  currentProject: project,
}

const newClient: Client = { id: null, firstName: '', lastName: '', company: '' };

const clients: Client[] = [
  {
    id: '1',
    firstName: 'John',
    lastName: 'Doe',
    company: 'Acme, Inc',
  },
  {
    id: '2',
    firstName: 'Jane',
    lastName: 'Smith',
    company: 'Super Dooper, Inc',
  }
];

const initialClientState: ClientsState = {
  clients,
  currentClient: newClient,
}

// -------------------------------------------------------------------
// METHODS
// -------------------------------------------------------------------

const add = (a, b) => a + b;
const sub = (a, b) => a - b;
const total = add(100, 300);

const coolClient: Client = {
  id: '100',
  firstName: 'Hawk',
  lastName: 'Eye',
  company: 'MCU'
}

// -------------------------------------------------------------------
// CONDITIONS
// -------------------------------------------------------------------

interface Action {
  type: string;
  payload?: any;
}

const loadClients = (state, action: Action): ClientsState => {
  return {
    clients: action.payload,
    currentClient: state.currentClient,
  }
}

const selectClient = (state, action: Action): ClientsState => {
  return {
    clients: state.clients,
    currentClient: action.payload,
  }
}

const createClient = (state, action: Action): ClientsState => {
  return {
    clients: [...state.clients, action.payload], // Iterators
    currentClient: state.currentClient,
  }
}

const updateClient = (state, action: Action): ClientsState => {
  return {
    clients: state.clients.map(client => { // Iterators
      return (client.id === action.payload.id)
        ? Object.assign({}, client, action.payload)
        : client;
    }),
    currentClient: state.currentClient,
  }
}

const deleteClient = (state, action: Action): ClientsState => {
  return {
    clients: state.clients.filter(client => client.id !== action.payload.id), // Iterators
    currentClient: state.currentClient,
  }
}

const LOAD_CLIENTS = '[Clients] Load Client';
const SELECT_CLIENT = '[Clients] Select Client';
const CREATE_CLIENT = '[Clients] Create Client';
const UPDATE_CLIENT = '[Clients] Update Client';
const DELETE_CLIENT = '[Clients] Delete Client';

const reducer = (state, action: Action) => {
  switch (action.type) {
    case LOAD_CLIENTS:
      return loadClients(state, action);
    case SELECT_CLIENT:
      return selectClient(state, action);
    case CREATE_CLIENT:
      return createClient(state, action);
    case UPDATE_CLIENT:
      return updateClient(state, action);
    case DELETE_CLIENT:
      return deleteClient(state, action);
    default:
      return state;
  }
}

const brandNewClient = { 
  id: '12345', 
  firstName: 'Douglas', 
  lastName: 'Adams', 
  company: 'Author Corp' 
};

class Store {
  state;
  reducer;

  constructor(state, reducer) {
    this.state = state;
    this.reducer = reducer;
  }

  getState() {
    return this.state;
  }

  select(key) {
    return this.state[key];
  }

  dispatch(action) {
    this.state = this.reducer(this.state, action);
  }
}

const clientsStore = new Store(initialClientState, reducer);
const currentClient = clientsStore.select('currentClient');
const newClientsState = clientsStore.dispatch({type: SELECT_CLIENT, payload: coolClient});
const newCurrentClient = clientsStore.select('currentClient');

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `<h1><pre>${JSON.stringify(newCurrentClient, null, 2)}</pre></h1>`;