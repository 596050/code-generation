// Import stylesheets
import './style.css';

// Handle the logic for iterating the group
const parseClientResponses = (responses) => {
  return responses.map(response => parseClientResponse(response))
}

// Handle the logic at the individual level
const parseClientResponse = (response) => {
  return executeCloudTask(response);
}

const executeCloudTask = (response) => {
  return reverse(response);
}

const reverse = (response) => response.split('').reverse().join('');

const clientResponses = [
  'response 00',
  'response 01',
  'response 02',
  'response 03',
  'response 04',
  'response 05',
  'response 06',
  'response 07',
  'response 08',
  'response 09',
];

const parsedResponses = parseClientResponses(clientResponses);

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `
  <h2>PRE</h2>
  <pre><h3>${JSON.stringify(clientResponses, null, 2)}</h3></pre>
  
  <h2>POST</h2>
  <pre><h3>${JSON.stringify(parsedResponses, null, 2)}</h3></pre>
`;