import './style.css';
import 'highlight.js/styles/tomorrow-night-bright.css';

import hljs from 'highlight.js';
import typescript from 'highlight.js/lib/languages/typescript';

hljs.registerLanguage('typescript', typescript);

import { ServiceGenerator } from './service-generator';
import { ReducerGenerator } from './reducer-generator';
import { Config, Schema } from './meta-models';

const courseSchema: Schema = {
  model: 'course',
  modelPlural: 'courses',
};

const lessonSchema: Schema = {
  model: 'lesson',
  modelPlural: 'lessons',
};

const assignmentSchema: Schema = {
  model: 'assignment',
  modelPlural: 'assignments',
};

const challengesSchema: Schema = {
  model: 'challenge',
  modelPlural: 'challenges',
};

const domain: Schema[] = [
  courseSchema,
  lessonSchema,
  assignmentSchema,
  challengesSchema,
];

const config: Config = {
  name: 'Workshop Config',
  application: 'dashboard',
  scope: 'acme',
};

// CHALLENGE: How would we generate a layer?
const generateLayer = (generator, domain, config) =>
  `<pre><code class="language-typescript">// Pending</code></pre>`;

const appDiv: HTMLElement = document.getElementById('app');

appDiv.innerHTML += `<h2>Data Layer</h2>`;
appDiv.innerHTML += generateLayer(ServiceGenerator, domain, config);
appDiv.innerHTML += `<h2>State Layer</h2>`;
appDiv.innerHTML += generateLayer(ReducerGenerator, domain, config);

hljs.highlightAll();
