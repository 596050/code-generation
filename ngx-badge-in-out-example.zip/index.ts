// Import stylesheets
import './style.css';
import moment from 'moment';

const events = [];

interface Event {
  uuid: string;
  occurred: string;
  actorId: string;
  actorName: string;
  siteName: string;
  readerName: string;
}

enum Status {
  ENTRY = 'Entry',
  INTERNAL = 'Internal',
  INTERNAL_ONLY = 'Internal Only',
}

interface Actor {
  actorId: string;
  actorName: string;
  events: Event[];
  flagged: boolean;
}

export class ActorService {
  filterTodaysEvents(events: Event[]) {
    const todaysDate = moment().format('MM-DD-YYYY');

    return events.filter(
      event => moment(event.occurred).format('MM-DD-YYYY') === todaysDate);
  }

  getUniqueActors(events: Event[]) {
    let uniqueActors: Actor[] = [];
    const actorsMap = new Map();
    events.forEach(event => {
      if (!actorsMap.has(event.actorName)) {
        actorsMap.set(event.actorName, true);
        uniqueActors = [
          ...uniqueActors,
          this.buildActor(event)
        ];
      }
    });

    return uniqueActors;
  }

  buildActor(event: Event): Actor {
    return {
      actorId: event.actorId,
      actorName: event.actorName,
      events: [],
      flagged: false,
    }
  }

  groupEventsByActor(events: Event[]) {
    const actors = this.getUniqueActors(events);
    actors.forEach(actor => {
      const actorEvents = events.filter(event => actor.actorId === event.actorId);
      actor.events = this.sortEventsByDate(actorEvents);
    })

    return actors;
  }

  pruneOutActors(actors: Actor[]) {
    return actors.filter(actor => {
      const firstEvent = actor.events[0];
      return !this.isOutEvent(firstEvent);
    });
  }


  flagActors(actors: Actor[]) {
    return actors.map(actor => this.flagActor(actor));
  }

  // NOTES
  // There are three possible scenarios
  // 1. A user has INTERNAL events preceded by an IN event - they are compliant
  // 2. A user has INTERNAL events preceded by an OUT event - they are non-compliant
  // 3. A user only has INTERNAL events - they are non-compliant

  flagActor(actor: Actor) {
    for (let i = 0, len = actor.events.length; i < len; i++) {
      const event = actor.events[i];
      if (this.isOutEvent(event)) {
        actor.flagged = true; // OUT EVENT: non-compliant
        break;
      }
      if (this.isInEvent(event)) {
        actor.flagged = false; // IN EVENT: compliant
        break;
      }
      actor.flagged = true; // INTERNAL ONLY EVENTS: non-compliant
    }

    return actor;
  }

  generateStatusMessage(actor: Actor) {
    const lastEvent = actor.events[0];
    // If OUT event... do nothing
    if(this.isOutEvent(lastEvent)) return;
    // If IN event... return ENTRY status
    if(this.isInEvent(lastEvent)) return Status.ENTRY;
    // If INTERNAL event AND NOT flagged... return INTERNAL status
    if(this.isInternalEvent(lastEvent) && !actor.flagged) return Status.INTERNAL;
    // If INTERNAL event AND flagged... return INTERNAL_ONLY status
    if(this.isInternalEvent(lastEvent) && actor.flagged) return Status.INTERNAL_ONLY;
  }

  filterNonCompliantActors(actors: Actor[]) {
    return actors.filter(actor => actor.flagged);
  }

  isInEvent(event: Event) {
    return /-IN_/.test(event.readerName);
  }

  isOutEvent(event: Event) {
    return /-OUT_/.test(event.readerName);
  }

  isInOrOutEvent(event: Event) {
    return /-IN_/.test(event.readerName) || /-OUT_/.test(event.readerName);
  }

  isInternalEvent(event: Event) {
    return !this.isInOrOutEvent(event);
  }

  sortEventsByDate(events) {
    return events.sort((a, b) => a.occurred - b.occurred);
  }
}

const service = new ActorService();

// 00: Get JUST today's events
const parsedEvents = service.filterTodaysEvents(events);
// 01: Group events by actor
const actors = service.groupEventsByActor(parsedEvents);
// 02: Filter out actors whose last event is OUT
const prunedActors = service.pruneOutActors(actors);
// 03: Process remaining actors and flag non-compliant actors
const flaggedActors = service.flagActors(prunedActors);
// 04: OPTIONAL: Display ONLY non-compliant actors
const nonCompliantActors = service.filterNonCompliantActors(flaggedActors);

// -------------------------------------------------------------------
// TEST
// -------------------------------------------------------------------
const inEvent: Event = {
  uuid: '1234',
  occurred: '06-11-2019',
  actorId: '1234',
  actorName: 'Actor Name',
  siteName: 'Site Name',
  readerName: 'reader-IN_name'
};

const outEvent: Event = {
  uuid: '1234',
  occurred: '06-11-2019',
  actorId: '1234',
  actorName: 'Actor Name',
  siteName: 'Site Name',
  readerName: 'reader-OUT_name'
};

const internalEvent: Event = {
  uuid: '1234',
  occurred: '06-11-2019',
  actorId: '1234',
  actorName: 'Actor Name',
  siteName: 'Site Name',
  readerName: 'reader-internal_name'
};

const entryActor: Actor = {
  actorId: '1234',
  actorName: 'In Actor',
  events: [
    inEvent,
  ],
  flagged: false,
}


const inActor: Actor = {
  actorId: '1234',
  actorName: 'In Actor',
  events: [
    internalEvent,
    internalEvent,
    inEvent,
  ],
  flagged: false,
}

const outActor: Actor = {
  actorId: '1234',
  actorName: 'Out Actor',
  events: [
    internalEvent,
    internalEvent,
    outEvent,
  ],
  flagged: false,
}

const internalActor: Actor = {
  actorId: '1234',
  actorName: 'Internal Actor',
  events: [
    internalEvent,
    internalEvent,
    internalEvent,
  ],
  flagged: false,
}

const flagEntryActor = service.flagActor(entryActor);

const flagInActor = service.flagActor(inActor);

const flagOutActor = service.flagActor(outActor);

const flagInternalActor = service.flagActor(internalActor);

const flagActors = [
  flagEntryActor,
  flagInActor,
  flagOutActor,
  flagInternalActor,
];

console.log('ENTRY ACTOR FLAGGED', flagEntryActor.flagged);
console.log('IN ACTOR FLAGGED', flagInActor.flagged);
console.log('OUT ACTOR FLAGGED', flagOutActor.flagged);
console.log('INTERNAL ACTOR FLAGGED', flagInternalActor.flagged);

console.log('ENTRY ACTOR MESSAGE', service.generateStatusMessage(entryActor));
console.log('IN ACTOR MESSAGE', service.generateStatusMessage(inActor));
console.log('OUT ACTOR MESSAGE', service.generateStatusMessage(outActor));
console.log('INTERNAL ACTOR MESSAGE', service.generateStatusMessage(internalActor));

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `<h4><pre>${JSON.stringify(flagActors, null, 2)}</pre></h4>`;