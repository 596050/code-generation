// Import stylesheets
import './style.css';

let output = '';

const ORG = 'presolved';

const DATA_MODULE = 'core-data';
const STATE_MODULE = 'core-state';
const AMPLIFY_MODULE = 'aws-amplify';
const GRAPHQL_MODULE = 'apollo-graphql';
const MATERIAL_MODULE = 'material';
const LOGIN_MODULE = 'ui-login';
const TOOLBAR_MODULE = 'ui-toolbar';

const libs = [
  DATA_MODULE,
  STATE_MODULE,
  AMPLIFY_MODULE,
  GRAPHQL_MODULE,
  MATERIAL_MODULE,
  LOGIN_MODULE,
  TOOLBAR_MODULE,
];

// client
// project
// resource

const entities = [
  { plural: 'clients', singular: 'client' },
  { plural: 'projects', singular: 'project' },
  { plural: 'resources', singular: 'resource' },
];

const apiEntities = [...entities];

// -------------------------------------------------------------------
// SERVICE LAYER
// -------------------------------------------------------------------
const generateCoreLib = (lib, suffix) =>
  (output += `\n nx g lib ${lib} ${suffix}`);

const generateService = (entity) => {
  output += `\n ng g s services/${entity.plural}/${entity.plural} \\
    --project=${DATA_MODULE} && \\`;
};

const generateNgRx = (entity) => {
  output += `\n ng g @nrwl/angular:ngrx ${entity.plural} \\
    --module=libs/${STATE_MODULE}/src/lib/${STATE_MODULE}.module.ts \\
    --directory ${entity.plural} \\
    --defaults \\
    --facade && \\`;
};

const generateDataLayer = (entities) => {
  entities.forEach((entity) => generateService(entity));
};

const generateStateLayer = (entities) => {
  entities.forEach((entity) => generateNgRx(entity));
};

// -------------------------------------------------------------------
// API LAYER
// -------------------------------------------------------------------

const generateAPIController = (entity) => {
  output += `\n ng g @nestjs/schematics:controller ${entity.plural} --source-root apps/api/src && \\`;
};

const generateAPIService = (entity) => {
  output += `\n ng g @nestjs/schematics:service ${entity.plural} --source-root apps/api/src && \\`;
};

const generateAPILayer = (entities) => {
  entities.forEach((entity) => generateAPIController(entity));
  entities.forEach((entity) => generateAPIService(entity));
};

// -------------------------------------------------------------------
// COMPONENT LAYER
// -------------------------------------------------------------------
const generateContainerComponent = (entity, suffix) => {
  output += `\n ng g c ${entity.plural} ${suffix}`;
};

const generateListComponent = (entity, suffix) => {
  output += `\n ng g c ${entity.plural}/${entity.plural}-list ${suffix}`;
};

const generateDetailsComponent = (entity, suffix) => {
  output += `\n ng g c ${entity.plural}/${entity.singular}-details ${suffix}`;
};

const generateLibComponent = (component, project, suffix) => {
  output += `\n ng g c ${component} --project ${project} ${suffix}`;
};

const generateComponentLayer = (entities, suffix) => {
  entities.forEach((entity) => {
    generateContainerComponent(entity, suffix);
    generateListComponent(entity, suffix);
    generateDetailsComponent(entity, suffix);
  });
};

// -------------------------------------------------------------------
// THE PROJECT
// -------------------------------------------------------------------
const generateIonicProject = (project) =>
  (output += `\n ionic start ${project} sidemenu`);

// -------------------------------------------------------------------
// THE PAGES
// -------------------------------------------------------------------

const generatePages = (pages) => {
  pages.forEach((page) => (output += `\n ionic g page ${page} && \\`));
};

const generateNav = (pages) => {
  pages.forEach(
    (page) =>
      (output += `
    {
      title: '${page.title}',
      url: '/${page.url}',
      icon: '${page.icon}'
    },`)
  );
};

// -------------------------------------------------------------------
// THE COMPONENTS
// -------------------------------------------------------------------

const generateComponents = (components) => {
  components.forEach(
    (component) => (output += `\n ionic g component ${component} && \\`)
  );
};

// -------------------------------------------------------------------
// THE MAGIC
// -------------------------------------------------------------------
const libSuffix = '--style=scss && \\';
const componentSuffix = '-m app.module.ts --style=scss && \\';

const logMessage = (message) =>
  (output += `\n\n <strong>${message}</strong> \n`);
const generateWorkspace = (org) =>
  (output += `\n npx create-nx-workspace@latest ${org}`);
const generateLibs = (libs, suffix) =>
  libs.forEach((lib) => generateCoreLib(lib, suffix));

const project = 'suitespot-poc';

const mainPages = [
  { title: 'Tasks', icon: 'file-tray', url: 'tasks' },
  { title: 'Jobs', icon: 'briefcase', url: 'search-jobs' },
  { title: 'Worklogs', icon: 'clipboard', url: 'worklogs' },
  { title: 'Calendar', icon: 'calendar', url: 'tasks' },
  { title: 'Notifications', icon: 'notifications', url: 'notification-center' },
  { title: 'Settings', icon: 'settings', url: 'settings' },
  { title: 'Support', icon: 'help-circle', url: 'contractor-portal' },
  { title: 'Login', icon: 'log-out', url: 'login' },
];

const pages = [
  'pages/approvals',
  'pages/contractor-portal',
  'pages/deliver-chargeback-letter',
  'pages/inspection',
  'pages/inspection/item/check',
  'pages/inspection/item/nfc',
  'pages/inspection/item/scope',
  'pages/inspection/item/signature',
  'pages/inspection/item/universal',
  'pages/inspection/photo-thumbnail',
  'pages/inspection/photo-viewer',
  'pages/inspection/scope',
  'pages/inspection/scope/roi-summary-card',
  'pages/inspection/scope/vendor-editor',
  'pages/login',
  'pages/material-tracking',
  'pages/milestones',
  'pages/notification-center',
  'pages/notification-center/notification-message-list-item',
  'pages/notification-center/notification-messages',
  'pages/password-reset',
  'pages/photo-editor-page',
  'pages/photo-editor-page/annotation-color-picker',
  'pages/price-quotes',
  'pages/purchase-orders',
  'pages/quick-actions',
  'pages/review-inspection',
  'pages/scope-approval',
  'pages/scope-dispatch',
  'pages/scope-editor',
  'pages/scope-work-orders',
  'pages/search-jobs',
  'pages/search-jobs/general-jobs-filter',
  'pages/search-jobs/job-results-list',
  'pages/search-jobs/quick-filter-item-selector',
  'pages/search-jobs/sort-by-selector',
  'pages/service-request',
  'pages/settings',
  'pages/settings/change-password',
  'pages/software-update',
  'pages/task-runner/task-runner',
  'pages/tasks',
  'pages/tasks/assign-task',
  'pages/tasks/workflow-details-cell',
  'pages/work-order-entity-task-quick-actions',
  'pages/work-order',
  'pages/work-schedule',
  'pages/create-job',
  'pages/workflows',
  'pages/worklogs',
];

const components = [
  'components/AnnotationColorPicker',
  'components/ApprovalCard',
  'components/ApprovalStateIcon',
  'components/ApprovalStateText',
  'components/AssignTask',
  'components/BaseFieldWidget',
  'components/CheckItemCell',
  'components/ContractorPortalMenu',
  'components/ContractorPriceQuoteList',
  'components/DateChangedMessage',
  'components/ExpenseLogs',
  'components/FieldCheckWidget',
  'components/FieldInputWidget',
  'components/FieldLabel',
  'components/FieldNumberSpinnerWidget',
  'components/FieldRadioWidget',
  'components/FieldRangeWidget',
  'components/FieldSwitchWidget',
  'components/GLCodeItem',
  'components/GLCodeSearch',
  'components/GeneralJobsFilterPage',
  'components/GenericSwitchWidget',
  'components/InspectionAreaListItem',
  'components/InspectionEditor',
  'components/InspectionRootTaskItem',
  'components/ItemsListItem',
  'components/JobResultsListPage',
  'components/MaterialLog',
  'components/MaterialLogEditorModal',
  'components/MaterialLogs',
  'components/MilestonesProgress',
  'components/MoveoutWorkflowDetail',
  'components/NFCItemCell',
  'components/NFCScanningModal',
  'components/NotificationMessage',
  'components/NotificationMessageDetails',
  'components/NotificationMessageIdentities',
  'components/NotificationMessageListItem',
  'components/NotificationMessageSlidingActionButtons',
  'components/NotificationMessageTimestamp',
  'components/OptionListItem',
  'components/PasswordReset',
  'components/PasswordResetRequest',
  'components/PhotoThumbnail',
  'components/PriceQuoteActionMessage',
  'components/PriceQuoteBounceMessage',
  'components/PriceQuoteList',
  'components/PriceQuoteStateIcon',
  'components/PriceQuoteStateText',
  'components/PurchaseOrderCard',
  'components/PurchaseOrderList',
  'components/PurchaseOrderStateIcon',
  'components/PurchaseOrderStateText',
  'components/QuickFilterItemSelector',
  'components/RelatedItemModal',
  'components/RoiSummaryCard',
  'components/ScopeAreaCategories',
  'components/ScopeAreaListItem',
  'components/ScopeAreaPage',
  'components/ScopeDispatcher',
  'components/ScopeDispatcherItemsGroupHeader',
  'components/ScopeEditor',
  'components/ScopeItemCell',
  'components/ScopeItem',
  'components/ScopeItemGroup',
  'components/ScopeItemPopover',
  'components/ScopeItemView',
  'components/ScopeList',
  'components/ScopeOverview',
  'components/ScopeReview',
  'components/ScopeReviewHeader',
  'components/ScopeReviewItem',
  'components/ScopeReviewItemHeader',
  'components/ScopeWorkOrderCard',
  'components/ScopeWorkOrderList',
  'components/ScopeWorkOrderStateIcon',
  'components/ScopeWorkOrderStateText',
  'components/ServiceRequestRequiresAttention',
  'components/SignatureItemCell',
  'components/SnoozeTaskActions',
  'components/SortBySelector',
  'components/TaskAssignedMessage',
  'components/TaskScheduleAction',
  'components/UniversalItemCell',
  'components/UniversalItemField',
  'components/WorkCommencementDateChangedMessage',
  'components/WorkDocumentsList',
  'components/WorkEvent',
  'components/WorkEventEditor',
  'components/WorkEvents',
  'components/WorkOrderItem',
  'components/WorkOrderItems',
  'components/WorkOrderNoteUpdatedMessage',
  'components/WorkOrderNotes',
  'components/WorkOrderOptions',
  'components/WorkOrderOptionsPopover',
  'components/WorkOrderPickerModal',
  'components/WorkOrderPurchaseRequisitions',
  'components/WorkSchedule',
  'components/WorkSchedulePage',
  'components/WorkflowActiveTasks',
  'components/WorkflowDetailsCell',
  'components/WorkflowDocuments',
  'components/WorkflowPriceQuotes',
  'components/WorkflowPurchaseOrders',
  'components/WorkflowSchedule',
  'components/WorkflowScopeWorkOrders',
  'components/WorkflowScopes',
  'components/WorkflowWorkOrders',
  'components/Worklogs',
];

logMessage('STEP 00: Generate project');
generateIonicProject(project);

logMessage('STEP 01: Generate pages');
generatePages(pages);

logMessage('STEP 02: Generate side nav');
generateNav(mainPages);

logMessage('STEP 03: Generate components');
generateComponents(components);

// logMessage('STEP 00: Generate workspace');
// generateWorkspace(ORG);

// logMessage('STEP 01: Generate libs');
// generateLibs(libs, libSuffix);

// logMessage('STEP 02: Generate remote data services');
// generateDataLayer(entities);

// logMessage('STEP 03: Generate ngrx services');
// generateStateLayer(entities);

// logMessage('STEP 04: Generate components for main features');
// generateComponentLayer(entities, componentSuffix);

// logMessage('STEP 05: Generate speciality components for libs');
// generateLibComponent('login', 'ui-login', libSuffix);
// generateLibComponent('toolbar', 'ui-toolbar', libSuffix);

// generateService({single: 'aws-amplify', plural: 'aws-amplify'});
// generateService({single: 'config', plural: 'config'});
// generateService({single: 'notification', plural: 'notifications'});

// generateContainerComponent({plural: 'home'}, componentSuffix);

// logMessage('STEP 06: Generate API layer');
// generateAPILayer(apiEntities);

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `<pre>${output}</pre>`;
