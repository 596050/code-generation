// Import stylesheets
import './style.css';

interface Client {
  id: string;
  name: string;
}

interface Project {
  id: string;
  title: string;
  clientId: string;
  client?: Client;
}

const clients: Client[] = [
  { id: '1', name: 'First Client' },
  { id: '2', name: 'Second Client' },
]

const projects: Project[] = [
  { id: '1', title: 'First Project', clientId: '1' },
  { id: '2', title: 'Second Project', clientId: '1' },
  { id: '3', title: 'Third Project', clientId: '2' },
]

const mapProjectsWithClients = (projects, clients) => {
  return projects.map(project => {
    return {
      ...project,
      client: clients.find(client => client.id === project.clientId)
    }
  })
}

const projectsWithClients = mapProjectsWithClients(projects, clients);

// Reducer is not an appropriate method here
// const mapProjectsWithClientNames = (projects, clients) => 
//   projects.reduce((acc, project) => {
//     const client = clients.find(c => c.id === project.projectId);
//       return acc.concat({
//         ...project,
//         ...client
//       });
//   }, []);


// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `<pre><h3>${JSON.stringify(projectsWithClients, null, 2)}</h3></pre>`;