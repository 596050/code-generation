import './style.css';
import 'highlight.js/styles/tomorrow-night-bright.css';

import hljs from 'highlight.js';
import typescript from 'highlight.js/lib/languages/typescript';

hljs.registerLanguage('typescript', typescript);

import { ServiceGenerator } from './service-generator';
import { ReducerGenerator } from './reducer-generator';
import { Config, Schema } from './meta-models';

const courseSchema: Schema = {
  model: 'course',
  modelPlural: 'courses',
};

const lessonSchema: Schema = {
  model: 'lesson',
  modelPlural: 'lessons',
};

const assignmentSchema: Schema = {
  model: 'assignment',
  modelPlural: 'assignments',
};

const domain: Schema[] = [courseSchema, lessonSchema, assignmentSchema];

const config: Config = {
  name: 'Workshop Config',
  application: 'dashboard',
  scope: 'acme',
};

const generateLayer = (generator, domain, config) =>
  domain.reduce((code, schema) => {
    code += `<pre><code class="language-typescript">
    ${generator.generate(schema, config).template}
    </code></pre>`;
    return code;
  }, '');

const appDiv: HTMLElement = document.getElementById('app');

appDiv.innerHTML += `<h2>Data Layer</h2>`;
appDiv.innerHTML += generateLayer(ServiceGenerator, domain, config);

appDiv.innerHTML += `<h2>State Layer</h2>`;
appDiv.innerHTML += generateLayer(ReducerGenerator, domain, config);

hljs.highlightAll();
