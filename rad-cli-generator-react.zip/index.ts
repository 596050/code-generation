import './style.css';
import 'highlight.js/styles/tomorrow-night-bright.css';

import hljs from 'highlight.js';
import bash from 'highlight.js/lib/languages/bash';

hljs.registerLanguage('bash', bash);

export interface Workspace {
  title: string;
  description?: string;
  config: Config;
  cli: CLI;
  schemas: Schema[];
}

export interface Config {
  name: string;
  application: string;
  scope: string;
  type: string;
}

export interface CLI {
  packages?: string[];
  dependencies?: string[];
  libs?: string[];
  detached?: {
    [key: string]: Schema;
  };
  suffixes: {
    [key: string]: string;
  };
}

export interface Command {
  func: Function;
  params: any;
}

export interface Schema {
  model: string;
  modelPlural: string;
}

const DATA_MODULE = 'core-data';
const STATE_MODULE = 'core-state';
const MATERIAL_MODULE = 'material';
const LOGIN_MODULE = 'ui-login';

// -------------------------------------------------------------------
// FUNCTIONALITY
// -------------------------------------------------------------------

const workspace = ({ config }) =>
  `npx create-nx-workspace@latest ${config.name} \\
  --appName=${config.application} \\
  --preset=${config.type} \\
  --npmScope=${config.scope} \\
  --nx-cloud=false \\
  --linter=eslint \\
  --style=scss && \\
cd ${config.name}/ && \\\n`;

const packages = ({ cli }) =>
  cli.packages.reduce((code, dependency) => {
    return (code += `npm i ${dependency} --force && \\\n`);
  }, '');

const dependencies = ({ cli }) =>
  cli.dependencies.reduce((code, dependency) => {
    return (code += `npx nx g ${dependency}:ng-add --no-interactive && \\\n`);
  }, '');

const libs = ({ cli }) =>
  cli.libs.reduce((code, lib) => {
    return (code += `nx g lib ${lib} ${cli.suffixes.lib} && \\\n`);
  }, '');

const homeComponent = ({ cli }) =>
  containerComponent({
    schema: cli.detached.home,
    suffix: cli.suffixes.component,
  });

const containerComponent = ({ schema, suffix = '' }) =>
  `nx g c ${schema.modelPlural} ${suffix} && \\\n`;

const listComponent = ({ schema, suffix = '' }) =>
  `nx g c ${schema.modelPlural}-list --directory=${schema.modelPlural} ${suffix} && \\\n`;

const detailsComponent = ({ schema, suffix = '' }) =>
  `nx g c ${schema.model}-details --directory=${schema.modelPlural}  ${suffix} && \\\n`;

const componentLayer = ({ cli, schemas }) =>
  schemas.reduce((code, schema) => {
    code += containerComponent({ schema, suffix: cli.suffixes.component });
    code += listComponent({ schema, suffix: cli.suffixes.component });
    code += detailsComponent({ schema, suffix: cli.suffixes.component });
    return code;
  }, '');

const slice = ({ schemas }) =>
  schemas.reduce((code, schema) => {
    return (code += `nx g slice ${schema.modelPlural} \\
    --project ${STATE_MODULE} \\
    --directory ${schema.modelPlural} \\
    --no-interactive \\
    --facade && \\\n`);
  }, '');

const jsonServer = () => `mkdir server && touch server/db.json && \\\n`;

const start = () => `npx concurrently "npm start" "npm start api"`;

const generate = (commands) =>
  commands.reduce((code, command) => {
    code += command.func(command.params);
    return code;
  }, '');

// -------------------------------------------------------------------
// DATA
// -------------------------------------------------------------------

const userSchema: Schema = {
  model: 'user',
  modelPlural: 'users',
};

const courseSchema: Schema = {
  model: 'course',
  modelPlural: 'courses',
};

const lessonSchema: Schema = {
  model: 'lesson',
  modelPlural: 'lessons',
};

const assignmentSchema: Schema = {
  model: 'assignment',
  modelPlural: 'assignments',
};

const feedbackSchema: Schema = {
  model: 'feedback',
  modelPlural: 'feedback',
};

const homeSchema: Schema = {
  model: 'home',
  modelPlural: 'home',
};

const loginSchema: Schema = {
  model: 'login',
  modelPlural: 'login',
};

const schemas: Schema[] = [
  userSchema,
  courseSchema,
  lessonSchema,
  assignmentSchema,
  feedbackSchema,
];

const suffixes = {
  style: `--style=scss`,
  lib: `--component=false`,
  component: `--export=false --routing=true --style=scss`,
};

const cli: CLI = {
  packages: ['axios', '-D json-server', '-D concurrently', '@material-ui/core'],
  dependencies: [],
  libs: [DATA_MODULE, STATE_MODULE, MATERIAL_MODULE, LOGIN_MODULE],
  detached: {
    home: homeSchema,
    login: loginSchema,
  },
  suffixes,
};

const config: Config = {
  name: 'react-workshop',
  application: 'dashboard',
  scope: 'proto',
  type: 'react-express',
};

const demoSpace: Workspace = {
  title: 'React Application',
  config,
  cli,
  schemas,
};

const commands: Command[] = [
  { func: workspace, params: demoSpace },
  { func: packages, params: demoSpace },
  { func: dependencies, params: demoSpace },
  { func: libs, params: demoSpace },
  { func: slice, params: demoSpace },
  { func: componentLayer, params: demoSpace },
  { func: homeComponent, params: demoSpace },
  { func: jsonServer, params: demoSpace },
  { func: start, params: demoSpace },
];

const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `
<h2>CLI Ludicrous Mode</h2>
<pre>
<code class="language-bash">${generate(commands)}</code>  
</pre>
`;

hljs.highlightAll();
