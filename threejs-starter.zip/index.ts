import * as THREE from 'three';
import { gsap } from 'gsap';

import './style.css';

enum Colors {
  white = 0xffffff,
  grey = 0x333333,
}

// -------------------------------------------------------------------
// UTILITIES
// -------------------------------------------------------------------

const degreesToRadians = (degrees) => {
  return degrees * (Math.PI / 180);
};

const sizes = {
  width: window.innerWidth,
  height: window.innerHeight,
};

const center = (group) => {
  new THREE.Box3()
    .setFromObject(group)
    .getCenter(group.position)
    .multiplyScalar(-1);
  scene.add(group);
};

const random = (min, max, float = false) => {
  const val = Math.random() * (max - min) + min;

  if (float) {
    return val;
  }

  return Math.floor(val);
};

const isEvenOrOdd = (i) => (i % 2 === 0 ? 1 : -1);

// -------------------------------------------------------------------
// SETUP
// -------------------------------------------------------------------

// SCENE
const canvas = document.querySelector('[data-canvas]');
const scene = new THREE.Scene();

// RENDERER
const renderer = new THREE.WebGLRenderer({ canvas });

const render = (renderer) => {
  renderer.setSize(sizes.width, sizes.height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.render(scene, camera);
};

// CAMERA
const camera = new THREE.PerspectiveCamera(
  75,
  sizes.width / sizes.height,
  0.1,
  1000
);
camera.position.z = 5;
scene.add(camera);

// MATERIAL
const material = new THREE.MeshLambertMaterial({ color: Colors.white });

// LIGHTING
const lightAmbient = new THREE.AmbientLight(0x9eaeff, 0.2);
scene.add(lightAmbient);

const lightDirectional = new THREE.DirectionalLight(Colors.white, 1);
scene.add(lightDirectional);

lightDirectional.position.set(5, 5, 5);

// -------------------------------------------------------------------
// FIGURE
// -------------------------------------------------------------------

const dims = {
  body: {
    width: 1,
    height: 1.5,
    depth: 1,
  },
  head: {
    width: 1.4,
    height: 1.4,
    depth: 1.4,
    positionY: 1.65,
  },
  arms: {
    width: 0.25,
    height: 1,
    depth: 0.25,
  },
  legs: {
    width: 0.25,
    height: 0.4,
    depth: 0.25,
  },
  eyes: {
    width: 0.15,
    height: 12,
    depth: 8,
    positionZ: 0.7,
    positionY: -0.1,
  },
};

class Figure {
  props = {
    x: 0,
    y: -1,
    z: 0,
    ry: 0,
    angle: 0,
    armRotation: 0,
  };

  group;
  head;
  body;

  headHue;
  bodyHue;
  headLightness;
  bodyLightness;
  headMaterial;
  bodyMaterial;

  arms = [];

  constructor(private scene, params) {
    this.props = { ...this.props, ...params };
    this.group = new THREE.Group();
    this.scene.add(this.group);

    this.initColors();

    this.init();
  }

  init() {
    this.createBody();
    this.createHead();
    this.createArms();
  }

  initColors() {
    this.headHue = random(0, 360);
    this.bodyHue = random(0, 360);
    this.headLightness = random(40, 65);
    this.headMaterial = new THREE.MeshLambertMaterial({
      color: `hsl(${this.headHue}, 30%, ${this.headLightness}%)`,
    });
    this.bodyMaterial = new THREE.MeshLambertMaterial({
      color: `hsl(${this.bodyHue}, 85%, 50%)`,
    });
  }

  createBody() {
    this.body = new THREE.Group();
    const geometry = new THREE.BoxGeometry(
      dims.body.width,
      dims.body.height,
      dims.body.depth
    );
    const bodyMain = new THREE.Mesh(geometry, this.bodyMaterial);

    this.body.add(bodyMain);
    this.group.add(this.body);

    this.createLegs();
  }

  createHead() {
    this.head = new THREE.Group();
    const geometry = new THREE.BoxGeometry(
      dims.head.width,
      dims.head.height,
      dims.head.depth
    );
    const headMain = new THREE.Mesh(geometry, this.headMaterial);

    this.head.add(headMain);
    this.group.add(this.head);

    this.head.position.y = dims.head.positionY;

    this.createEyes();
  }

  createArms() {
    const geometry = new THREE.BoxGeometry(
      dims.arms.width,
      dims.arms.height,
      dims.arms.depth
    );

    for (let i = 0; i < 2; i++) {
      const armGroup = new THREE.Group();
      const arm = new THREE.Mesh(geometry, this.headMaterial);

      const m = isEvenOrOdd(i);

      armGroup.add(arm);
      this.arms.push(armGroup);
      this.group.add(armGroup);

      armGroup.position.x = m * 0.8; // REFACTOR
      armGroup.position.y = 0.6; // REFACTOR
      arm.position.y = dims.arms.height * -0.5; // REFACTOR

      armGroup.rotation.z = degreesToRadians(30 * m);
    }
  }

  createEyes() {
    const eyes = new THREE.Group();
    const geometry = new THREE.SphereGeometry(
      dims.eyes.width,
      dims.eyes.height,
      dims.eyes.depth
    );

    const material = new THREE.MeshLambertMaterial({ color: Colors.grey });

    for (let i = 0; i < 2; i++) {
      const eye = new THREE.Mesh(geometry, material);

      eye.position.x = 0.36 * isEvenOrOdd(i); // REFACTOR

      eyes.add(eye);
    }

    eyes.position.z = dims.eyes.positionZ;
    eyes.position.y = dims.eyes.positionY;

    this.head.add(eyes);
  }

  createLegs() {
    const legs = new THREE.Group();
    const geometry = new THREE.BoxGeometry(
      dims.legs.width,
      dims.legs.height,
      dims.legs.depth
    );

    for (let i = 0; i < 2; i++) {
      const leg = new THREE.Mesh(geometry, this.headMaterial);

      leg.position.x = isEvenOrOdd(i) * 0.22;

      legs.add(leg);
    }

    legs.position.y = -1.15;

    this.body.add(legs);
  }

  bounce() {
    this.group.rotation.y = this.props.ry;
    this.group.position.y = this.props.y;
    this.arms.forEach((arm, i) => {
      arm.rotation.z = this.props.armRotation * isEvenOrOdd(i);
    });
  }
}

const figure = new Figure(scene, {
  ry: degreesToRadians(30),
});

center(figure.group);

// -------------------------------------------------------------------
// ANIMATIONS
// -------------------------------------------------------------------

gsap.set(figure.props, {
  y: -1.5,
});

gsap.to(figure.props, {
  ry: degreesToRadians(360),
  repeat: -1,
  duration: 20,
});

gsap.to(figure.props, {
  y: 0,
  armRotation: degreesToRadians(90),
  repeat: -1,
  yoyo: true,
  duration: 0.5,
});

gsap.ticker.add(() => {
  figure.bounce();
  render(renderer);
});

// -------------------------------------------------------------------
// BOX
// -------------------------------------------------------------------

const boxDims = {
  width: 1,
  height: 1,
  depth: 1,
};

class Box {
  props = {
    x: 0,
    y: -1,
    z: 0,
    angle: 0,
  };

  group;
  body;

  hue;
  material;
  lightness;

  constructor(private scene, params) {
    this.props = { ...this.props, ...params };
    this.group = new THREE.Group();
    this.scene.add(this.group);

    this.initColors();
    this.initBody();
    this.positionBody();
  }

  initBody() {
    const geometry = new THREE.BoxGeometry(
      boxDims.width,
      boxDims.height,
      boxDims.depth
    );
    this.body = new THREE.Mesh(geometry, this.material);
    this.group.add(this.body);
  }

  initColors() {
    this.hue = random(0, 360);
    this.material = new THREE.MeshLambertMaterial({
      color: `hsl(${this.hue}, 85%, 50%)`,
    });
  }

  positionBody() {
    this.group.rotation.y = this.props.angle;
    this.group.rotation.x = this.props.angle;
  }
}

// const box = new Box(scene, {
//   angle: degreesToRadians(random(1, 180)),
// });

// center(box.group);

// -------------------------------------------------------------------
// LOGIC
// -------------------------------------------------------------------

window.addEventListener('resize', () => {
  // Update sizes
  sizes.width = window.innerWidth;
  sizes.height = window.innerHeight;

  // Update camera
  camera.aspect = sizes.width / sizes.height;
  camera.updateProjectionMatrix();

  // Update renderer
  render(renderer);
});

render(renderer);
