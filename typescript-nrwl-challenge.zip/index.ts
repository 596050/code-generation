// Import stylesheets
import './style.css';


// A1 needs to become A2
const a1 = [
  [1, 4, 7],
  [2, 5, 8],
  [3, 6, 9],
]

// 7 = [0][2]
// 7 = [2][0]

// 8 = [1][2]
// 8 = [2][1]

// first index what row
// second index is what column
// ANSWER: flip these indexes

const n1 = a1.map((outer, i) => outer.map((inner, j) => a1[j][i]));

// REFERENCE 
const a2 = [
  [1, 2, 3],
  [4, 5, 6],
  [7, 8, 9],
]

// WRONG // Order is not important Position is

// datastructure
// const t1 = [1, 2, 3, 4, 5, 6, 7, 8, 9];

// predefined slots
// const t2 = [
//   [null, null, null],
//   [null, null, null],
//   [null, null, null],
// ];

// Can I just go through and 'paint' the structure

// what is the length of t2 // 3
// what is th length of t2[0], t2[1], t2[2]

// t2[0].length = 3
// 'give me the first three items in t1 and fill t2[0]
// Repeat N times

// 00: convert a1 into t1
// const n1 = [].concat(...a1);
// const n2 = n1.slice().sort(); // T2 ACHIEVEMENT UNLOCKED!

// 01: iterate over a2 and return new data structure

// WRONG // Need to preserve 'shape'
// concat a1 into a single array
// sort a1
// break a1 into sub arrays 
// thus creating a2

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `<h1>${JSON.stringify(n1, null, 2)}</h1>`;