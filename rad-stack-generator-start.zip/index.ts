import './style.css';
import 'highlight.js/styles/tomorrow-night-bright.css';

import hljs from 'highlight.js';
import typescript from 'highlight.js/lib/languages/typescript';

hljs.registerLanguage('typescript', typescript);

import { ServiceGenerator } from './service-generator';
import { ReducerGenerator } from './reducer-generator';
import { Config, Schema } from './meta-models';

const courseSchema: Schema = {
  model: 'course',
  modelPlural: 'courses',
};

const lessonSchema: Schema = {
  model: 'lesson',
  modelPlural: 'lessons',
};

const assignmentSchema: Schema = {
  model: 'assignment',
  modelPlural: 'assignments',
};

const domain: Schema[] = [courseSchema, lessonSchema, assignmentSchema];

// CHALLENGE: How would we define a layer?
const layers = [];

const config: Config = {
  name: 'Workshop Config',
  application: 'dashboard',
  scope: 'acme',
};

const generateLayer = (generator, domain, config) =>
  domain.reduce((code, schema) => {
    code += `<pre><code class="language-typescript">
    ${generator.generate(schema, config).template}
    </code></pre>`;
    return code;
  }, '');

// CHALLENGE: How would we generate multiple layers
const generateStack = (layers, domain, config) =>
  `<pre><code class="language-typescript">// Pending</code></pre>`;

const appDiv: HTMLElement = document.getElementById('app');

appDiv.innerHTML += generateStack(layers, domain, config);

hljs.highlightAll();
