/**
 * Copyright 2018
 * 
 * author: joejordanbrown
 */

export class ServerLog {
  output(method, message, ...optionalParams) {
    // send HTTP request with console logs to server etc
  }
}