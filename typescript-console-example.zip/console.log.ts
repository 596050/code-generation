/**
 * Copyright 2018
 * 
 * author: joejordanbrown
 */

import { Subject } from 'rxjs/Subject';

export const orignalConsole = window.console;

window.console = {};

export class ConsoleWrapper {

  options = {
    defaultConsole: true,
    line: {
      colour: true,
      time: true
    }
  };

  callback = (method, message) => {};

  data = new Subject();

  constructor() {}

  log(message: any, ...optionalParams: any[]) {
    this.output('log', message, optionalParams);
  }

  info(message: any, ...optionalParams: any[]) {
    this.output('info', message, ...optionalParams);
  }

  warn(message: any, ...optionalParams: any[]) {
    this.output('warn', message, optionalParams);
  }

  error(message: any, ...optionalParams: any[]) {
    this.output('error', message, ...optionalParams);
  }

  debug(message: any, ...optionalParams: any[]) {
    if (optionalParams.length !== 0) {
      this.output('debug', message, ...optionalParams);
    } else {
      this.output('debug', message);
    }
  }

  clear() {
    if (this.options.defaultConsole) {
      orignalConsole.clear();
    }
    this.output('clear');
  }

  output(method, message = null, ...optionalParams: any[]) {
    if (this.options.defaultConsole) {
      orignalConsole[method](message, optionalParams);
    }
    if (optionalParams.length !== 0) {
      this.data.next({method, message, optionalParams})
    } else {
      this.data.next({method, message})
    }
  }
}

export const consoleWrapper = new ConsoleWrapper();

console.log = function(message: any, ...optionalParams: any[]){
  if (optionalParams.length !== 0) {
    consoleWrapper.log(message, ...optionalParams);
  } else {
    consoleWrapper.log(message);
  }
};
console.info = function(message: any, ...optionalParams: any[]){
  consoleWrapper.info(message, ...optionalParams);
};
console.warn = function(message: any, ...optionalParams: any[]){
  consoleWrapper.warn(message, ...optionalParams);
};
console.error = function(message: any, ...optionalParams: any[]){
  consoleWrapper.error(message, ...optionalParams);
};
console.debug = function(message: any, ...optionalParams: any[]){
  if (optionalParams.length !== 0) {
    consoleWrapper.debug(message, ...optionalParams);
  } else {
    consoleWrapper.debug(message);
  }
};
console.clear = function() {
  consoleWrapper.clear();
}