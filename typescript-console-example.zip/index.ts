import { orignalConsole, consoleWrapper } from './console.log';
import { HtmlLog } from './html.log';
import { ServerLog } from './server.log';

const htmlLog = new HtmlLog();
const serverLog = new ServerLog();
consoleWrapper.data.subscribe((data: any) => {
  // alert(JSON.stringify(data.optionalParams));
  htmlLog.output(data.method, data.message, data.optionalParams);
  serverLog.output(data.method, data.message, data.optionalParams);
});


console.log('log');

console.info('info');

console.warn('warn');

console.error('error');

console.debug('debug', {test: 'this'});