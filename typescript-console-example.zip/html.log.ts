/**
 * Copyright 2018
 * 
 * author: joejordanbrown
 */


const DEFAULTS = {
    error: "text-danger",
    warn: "text-warning",
    info: "text-success",
    debug: "text-info",
    log: ""
};


export class HtmlLog {
  output(method, message, ...optionalParams) {
    if (method === 'clear') {
      document.getElementById('target').textContent = '';
    }

    if (optionalParams.length !== 0) {
      message += JSON.stringify(optionalParams);
    
      const params = optionalParams.reduce((accumulator, currentValue) => {
        if (currentValue instanceof Object) {
          message += JSON.stringify(optionalParams[0][0]);
        }
        if (currentValue === '[object Object]') {
          currentValue = "Object " + JSON.stringify(currentValue);
          message += currentValue;
        }
        return accumulator + ' ' + currentValue;
      });

      message += params;
    }

    let li = document.createElement("li");
    li.setAttribute("data-level", method);
    li.innerText = this.transformOutput(message);
    li.setAttribute("class", DEFAULTS[method]);
    document.getElementById('target').appendChild(li); 
  }

  transformOutput(message) {
    let output = `[${new Date().toLocaleTimeString()}]: `;
    output += message;
    return output;
  }
}