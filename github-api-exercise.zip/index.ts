// Import stylesheets
import './style.css';

interface User {
  id: string;
  login: string;
  avatar_url: string;
}

interface PullRequest {
  id: string;
  url: string;
  number: number;
  state: string;
  title: string;
  user: User;
}

// Fetching Logic
const getURI = (owner, repo) => {
  return `https://api.github.com/repos/${owner}/${repo}/pulls`;
};

const getPullRequests = async () => {
  const response = await fetch(getURI('venmo', 'foundations-interview'));
  const pullRequests = await response.json();
  return pullRequests;
};

// Parsing Logic
const parseUser = ({ id, login, avatar_url }): User => ({
  id,
  login,
  avatar_url,
});

const parsePullRequest = ({
  id,
  url,
  number,
  state,
  title,
  user,
}): PullRequest => ({
  id,
  number,
  url,
  state,
  title,
  user: parseUser(user),
});

const parsePullRequests = (pullRequests): PullRequest[] =>
  pullRequests.map((pullRequest) => parsePullRequest(pullRequest));

// Utils
enum StateIcons {
  'open' = '✅',
  'closed' = '🛑',
}

const getStateIcon = (state) => StateIcons[state];

const getContainer = (): HTMLElement => document.getElementById('app');

const printPretty = (pullRequests: PullRequest[]) =>
  pullRequests.forEach(({ state, user, number, title }) =>
    print(`${getStateIcon(state)} ${user.login}: #${number} "${title}"<br />`)
  );

const printRaw = (message) => {
  print(`<pre>${JSON.stringify(message, null, 2)}</pre>`);
};

const print = (message) => (getContainer().innerHTML += message);
const clear = () => (getContainer().innerHTML = '');

// The Work
const init = async () => {
  const pullRequests = await getPullRequests();
  const parsedRequests = parsePullRequests(pullRequests);
  printPretty(parsedRequests);
};

init();
