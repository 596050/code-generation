// Import stylesheets
import './style.css';


const first = '135/95';
const second = '135/95/75';

const convert = val => {
  const s1 = val.split('/'); // Split on slash
  const s2 = s1.map(s => `${s}#`); // Add hash to each element
  const s3 = s2.join('/'); // Join back together with slash

  return s3;
}

const conciseConvert = val => {
  // We can chain these together and make it really clean
  return val.split('/')
    .map(s => `${s}#`)
    .join('/');
}

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `<h1>${conciseConvert(second)}</h1>`;