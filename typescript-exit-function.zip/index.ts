// Import stylesheets
import './style.css';

function blue() {
  return;
}

function red() {
  throw 'exit';
}

function safe() {
  console.log('Take the blue pill');
  blue();
  console.log('Took the blue pill');
}

function real() {
  console.log('Take the red pill');
  red();
  console.log('Took the red pill');
}

safe();
real();

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `<h1>TypeScript Starter</h1>`;
