// Import stylesheets
import './style.css';

// 1.1 Get the product of all other elements

// [1, 2, 3, 4, 5] would be [120, 60, 40, 30, 24]

const numbers = [1, 2, 3, 4, 5];

function calculateProduct(numbers: number[]) {
  const total = numbers.reduce((acc, curr) => acc * curr);
  return numbers.map(n => total / n);
}

function calculateProductv2(numbers: number[]) {
  return numbers.map((n, i) => {
    return numbers.reduce((acc, curr, j) => (i !== j ? acc * curr : acc));
  });
}

// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById('app');
appDiv.innerHTML = `
  <h3>Least Resistence</h3>
  ${calculateProduct(numbers)}
  
  <h3>Without Division</h3>
  ${calculateProductv2(numbers)}
`;
